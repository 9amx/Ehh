"use client"

import { useEffect, useRef } from "react"

export function CustomCursor() {
  const cursorOuterRef = useRef<HTMLDivElement>(null)
  const cursorInnerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    let lastX = 0
    let lastY = 0
    let requestId: number | null = null

    const moveCursor = (e: MouseEvent) => {
      lastX = e.clientX
      lastY = e.clientY

      if (!requestId) {
        requestId = requestAnimationFrame(updateCursor)
      }
    }

    const updateCursor = () => {
      if (cursorOuterRef.current && cursorInnerRef.current) {
        cursorOuterRef.current.style.transform = `translate(${lastX}px, ${lastY}px) translate(-50%, -50%)`
        cursorInnerRef.current.style.transform = `translate(${lastX}px, ${lastY}px) translate(-50%, -50%)`
      }
      requestId = null
    }

    window.addEventListener("mousemove", moveCursor)

    return () => {
      window.removeEventListener("mousemove", moveCursor)
      if (requestId) {
        cancelAnimationFrame(requestId)
      }
    }
  }, [])

  return (
    <>
      <div
        ref={cursorOuterRef}
        className="fixed w-8 h-8 rounded-full border-2 border-emerald-500 pointer-events-none z-50 mix-blend-difference"
        style={{ left: 0, top: 0 }}
      />
      <div
        ref={cursorInnerRef}
        className="fixed w-2 h-2 bg-cyan-500 rounded-full pointer-events-none z-50"
        style={{ left: 0, top: 0 }}
      />
    </>
  )
}

