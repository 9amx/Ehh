"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import { Shield, Lock, Code, Cpu, Server, Database, Globe, Wifi, Bug, Key } from "lucide-react"

interface FloatingIcon {
  id: number
  icon: React.ReactNode
  x: number
  y: number
  size: number
  rotation: number
  delay: number
}

export function FloatingIcons() {
  const [icons, setIcons] = useState<FloatingIcon[]>([])

  useEffect(() => {
    const iconComponents = [
      <Shield key="shield" size={24} />,
      <Lock key="lock" size={24} />,
      <Code key="code" size={24} />,
      <Cpu key="cpu" size={24} />,
      <Server key="server" size={24} />,
      <Database key="database" size={24} />,
      <Globe key="globe" size={24} />,
      <Wifi key="wifi" size={24} />,
      <Bug key="bug" size={24} />,
      <Key key="key" size={24} />,
    ]

    const newIcons: FloatingIcon[] = []

    // Reduce the number of floating icons
    for (let i = 0; i < 10; i++) {
      // Reduced from 20
      newIcons.push({
        id: i,
        icon: iconComponents[i % iconComponents.length],
        x: Math.random() * 100,
        y: Math.random() * 100,
        size: Math.random() * 0.5 + 0.5,
        rotation: Math.random() * 360,
        delay: Math.random() * 5,
      })
    }

    setIcons(newIcons)
  }, [])

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {icons.map((icon) => (
        <motion.div
          key={icon.id}
          className="absolute text-emerald-500/30"
          style={{
            left: `${icon.x}%`,
            top: `${icon.y}%`,
            transform: `scale(${icon.size}) rotate(${icon.rotation}deg)`,
          }}
          animate={{
            y: [0, -20, 0, 20, 0],
            x: [0, 10, 0, -10, 0],
            rotate: [icon.rotation, icon.rotation + 20, icon.rotation - 20, icon.rotation],
          }}
          transition={{
            duration: 10 + icon.delay,
            repeat: Number.POSITIVE_INFINITY,
            ease: "linear",
          }}
        >
          {icon.icon}
        </motion.div>
      ))}
    </div>
  )
}

