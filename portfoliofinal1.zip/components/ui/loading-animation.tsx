"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"

export function LoadingAnimation() {
  const [progress, setProgress] = useState(0)
  const [loadingText, setLoadingText] = useState("Initializing...")

  useEffect(() => {
    // Simulate loading progress
    const interval = setInterval(() => {
      setProgress((prev) => {
        const newProgress = prev + 1
        if (newProgress >= 100) {
          clearInterval(interval)
          return 100
        }
        return newProgress
      })
    }, 30)

    // Update loading text based on progress
    const textUpdates = [
      { threshold: 0, text: "Initializing..." },
      { threshold: 20, text: "Loading security modules..." },
      { threshold: 40, text: "Establishing secure connection..." },
      { threshold: 60, text: "Decrypting data..." },
      { threshold: 80, text: "Finalizing..." },
      { threshold: 95, text: "Access granted" },
    ]

    const textInterval = setInterval(() => {
      for (let i = textUpdates.length - 1; i >= 0; i--) {
        if (progress >= textUpdates[i].threshold) {
          setLoadingText(textUpdates[i].text)
          break
        }
      }

      if (progress >= 100) {
        clearInterval(textInterval)
      }
    }, 100)

    return () => {
      clearInterval(interval)
      clearInterval(textInterval)
    }
  }, [progress])

  return (
    <div className="flex flex-col items-center justify-center">
      <div className="mb-8 relative">
        <motion.div
          className="text-8xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-emerald-500 to-cyan-500 cyber-glow"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{
            opacity: [0, 1, 1, 1, 1],
            scale: [0.8, 1.2, 1, 1.1, 1],
            rotateY: [0, 0, 10, -10, 0],
            filter: ["blur(10px)", "blur(0px)", "blur(0px)", "blur(2px)", "blur(0px)"],
          }}
          transition={{
            duration: 2.5,
            times: [0, 0.2, 0.4, 0.6, 1],
            ease: "easeInOut",
          }}
        >
          9am
        </motion.div>

        {/* Glitch effect overlay */}
        <motion.div
          className="absolute inset-0 text-8xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-500 to-purple-500"
          initial={{ opacity: 0, x: -5 }}
          animate={{
            opacity: [0, 0.5, 0, 0.8, 0],
            x: [-5, 0, 5, -3, 0],
          }}
          transition={{
            duration: 1.5,
            repeat: 1,
            repeatDelay: 0.5,
          }}
        >
          9am
        </motion.div>

        {/* Code-like characters appearing and disappearing */}
        <motion.div
          className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none"
          initial={{ opacity: 0 }}
          animate={{ opacity: [0, 1, 0] }}
          transition={{ duration: 2, times: [0, 0.5, 1] }}
        >
          {Array.from({ length: 20 }).map((_, i) => (
            <motion.div
              key={i}
              className="absolute text-xs font-mono text-emerald-500/70"
              initial={{
                opacity: 0,
                x: Math.random() * 200 - 100,
                y: Math.random() * 100 - 50,
              }}
              animate={{
                opacity: [0, 1, 0],
                y: [0, Math.random() * 30 - 15],
              }}
              transition={{
                duration: 1 + Math.random(),
                delay: Math.random() * 1.5,
                ease: "easeInOut",
              }}
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
            >
              {String.fromCharCode(Math.floor(Math.random() * 94) + 33)}
            </motion.div>
          ))}
        </motion.div>
      </div>

      <div className="w-64 h-1 bg-gray-800 rounded-full overflow-hidden mb-4">
        <div className="h-full bg-gradient-to-r from-emerald-500 to-cyan-500" style={{ width: `${progress}%` }} />
      </div>

      <div className="font-mono text-sm text-emerald-500">{loadingText}</div>

      <div className="mt-4 font-mono text-xs text-gray-500">{progress}%</div>
    </div>
  )
}

