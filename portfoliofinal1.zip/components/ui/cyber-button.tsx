"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"

interface CyberButtonProps {
  children: React.ReactNode
  variant?: "primary" | "outline" | "ghost"
  className?: string
  onClick?: () => void
}

export function CyberButton({ children, variant = "default", className = "", onClick }: CyberButtonProps) {
  const [isHovered, setIsHovered] = useState(false)

  const getButtonStyles = () => {
    switch (variant) {
      case "primary":
        return "bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-600 hover:to-cyan-600 text-black font-medium"
      case "outline":
        return "bg-transparent border border-emerald-500/50 text-emerald-500 hover:bg-emerald-500/10"
      case "ghost":
        return "bg-transparent text-gray-400 hover:text-white hover:bg-gray-800/50"
      default:
        return "border border-emerald-500/50 text-emerald-500 hover:bg-emerald-500/10"
    }
  }

  return (
    <motion.button
      className={`relative px-6 py-2 rounded-md overflow-hidden ${getButtonStyles()} ${className}`}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      onClick={onClick}
      whileTap={{ scale: 0.98 }}
    >
      {variant !== "ghost" && (
        <>
          <motion.span
            className="absolute inset-0 bg-gradient-to-r from-emerald-500/20 to-cyan-500/20 opacity-0"
            animate={{ opacity: isHovered ? 1 : 0 }}
            transition={{ duration: 0.3 }}
          />

          <motion.span
            className="absolute top-0 right-0 w-1 h-full bg-emerald-500"
            initial={{ height: 0 }}
            animate={{ height: isHovered ? "100%" : "30%" }}
            transition={{ duration: 0.3 }}
          />

          <motion.span
            className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-500 to-cyan-500"
            initial={{ width: "30%" }}
            animate={{ width: isHovered ? "100%" : "30%" }}
            transition={{ duration: 0.3 }}
          />
        </>
      )}

      <span className="relative z-10">{children}</span>
    </motion.button>
  )
}

