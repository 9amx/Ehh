"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { Card } from "@/components/ui/card"

interface CyberCardProps {
  children: React.ReactNode
  className?: string
}

export function CyberCard({ children, className = "" }: CyberCardProps) {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <motion.div
      className={`relative rounded-lg overflow-hidden ${className}`}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      whileHover={{ scale: 1.02 }}
      transition={{ duration: 0.2 }}
    >
      <Card className="bg-gray-900/50 backdrop-blur-sm border-gray-800 overflow-hidden h-full relative z-10">
        {children}
      </Card>

      <motion.div
        className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-500 to-cyan-500"
        initial={{ width: "30%" }}
        animate={{ width: isHovered ? "100%" : "30%" }}
        transition={{ duration: 0.3 }}
      />

      <motion.div
        className="absolute top-0 right-0 w-1 h-full bg-gradient-to-b from-emerald-500 to-cyan-500"
        initial={{ height: "30%" }}
        animate={{ height: isHovered ? "100%" : "30%" }}
        transition={{ duration: 0.3 }}
      />

      <motion.div
        className="absolute bottom-0 right-0 w-full h-1 bg-gradient-to-l from-emerald-500 to-cyan-500"
        initial={{ width: "30%" }}
        animate={{ width: isHovered ? "100%" : "30%" }}
        transition={{ duration: 0.3 }}
      />

      <motion.div
        className="absolute bottom-0 left-0 w-1 h-full bg-gradient-to-t from-emerald-500 to-cyan-500"
        initial={{ height: "30%" }}
        animate={{ height: isHovered ? "100%" : "30%" }}
        transition={{ duration: 0.3 }}
      />
    </motion.div>
  )
}

