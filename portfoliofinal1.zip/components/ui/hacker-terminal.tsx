"use client"

import { useState, useEffect } from "react"

interface TerminalLine {
  text: string
  delay: number
}

interface HackerTerminalProps {
  lines: TerminalLine[]
  className?: string
}

export function HackerTerminal({ lines, className = "" }: HackerTerminalProps) {
  const [displayedLines, setDisplayedLines] = useState<string[]>([])
  const [currentLineIndex, setCurrentLineIndex] = useState(0)
  const [currentCharIndex, setCurrentCharIndex] = useState(0)

  useEffect(() => {
    if (currentLineIndex >= lines.length) return

    const currentLine = lines[currentLineIndex]

    if (currentCharIndex === 0) {
      // Start a new line
      setDisplayedLines((prev) => [...prev, ""])
    }

    if (currentCharIndex < currentLine.text.length) {
      const timer = setTimeout(() => {
        setDisplayedLines((prev) => {
          const newLines = [...prev]
          newLines[newLines.length - 1] = currentLine.text.substring(0, currentCharIndex + 1)
          return newLines
        })
        setCurrentCharIndex((prev) => prev + 1)
      }, 30) // Character typing speed

      return () => clearTimeout(timer)
    } else {
      // Line complete, move to next line after delay
      const timer = setTimeout(() => {
        setCurrentLineIndex((prev) => prev + 1)
        setCurrentCharIndex(0)
      }, currentLine.delay)

      return () => clearTimeout(timer)
    }
  }, [currentLineIndex, currentCharIndex, lines])

  return (
    <div className={`font-mono text-sm text-left ${className}`}>
      {displayedLines.map((line, index) => (
        <div key={index} className="flex">
          <span className="text-emerald-500 mr-2">
            {index === displayedLines.length - 1 && currentCharIndex < lines[currentLineIndex]?.text.length ? ">" : "$"}
          </span>
          <span>{line}</span>
          {index === displayedLines.length - 1 && currentCharIndex < lines[currentLineIndex]?.text.length && (
            <span className="ml-1 animate-pulse">|</span>
          )}
        </div>
      ))}
    </div>
  )
}

