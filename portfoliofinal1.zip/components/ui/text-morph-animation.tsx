"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"

interface TextMorphAnimationProps {
  phase: number
}

export function TextMorphAnimation({ phase }: TextMorphAnimationProps) {
  const [particles, setParticles] = useState<{ x: number; y: number; size: number; color: string; delay: number }[]>([])

  // Generate particles for the explosion effect
  useEffect(() => {
    if (phase === 2) {
      const newParticles = []
      for (let i = 0; i < 100; i++) {
        newParticles.push({
          x: Math.random() * 200 - 100,
          y: Math.random() * 200 - 100,
          size: Math.random() * 6 + 2,
          color: `hsl(${Math.random() * 60 + 140}, 100%, 50%)`,
          delay: Math.random() * 0.5,
        })
      }
      setParticles(newParticles)
    }
  }, [phase])

  // Initial animation - 9am text appears with glow
  if (phase === 0) {
    return (
      <div className="flex flex-col items-center justify-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="relative"
        >
          <div className="text-8xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-emerald-500 to-cyan-500 cyber-glow">
            9am
          </div>
        </motion.div>
      </div>
    )
  }

  // Second phase - 3D rotation and particle build-up
  if (phase === 1) {
    return (
      <div className="flex flex-col items-center justify-center perspective-[1000px]">
        <motion.div
          initial={{ rotateY: 0 }}
          animate={{
            rotateY: 360,
            z: [0, 100, 0],
            scale: [1, 1.2, 1],
          }}
          transition={{
            duration: 1.5,
            ease: "easeInOut",
          }}
          className="relative"
        >
          <div className="text-8xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-emerald-500 to-cyan-500 cyber-glow">
            9am
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8, duration: 0.5 }}
            className="absolute top-full left-1/2 transform -translate-x-1/2 mt-4"
          >
            <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-500 to-pink-500 cyber-glow">
              <motion.span
                initial={{ opacity: 0 }}
                animate={{ opacity: [0, 1, 0, 1, 0, 1] }}
                transition={{ duration: 0.5, times: [0, 0.2, 0.4, 0.6, 0.8, 1] }}
              >
                a
              </motion.span>
              <motion.span
                initial={{ opacity: 0 }}
                animate={{ opacity: [0, 1, 0, 1, 0, 1] }}
                transition={{ duration: 0.5, delay: 0.1, times: [0, 0.2, 0.4, 0.6, 0.8, 1] }}
              >
                k
              </motion.span>
              <motion.span
                initial={{ opacity: 0 }}
                animate={{ opacity: [0, 1, 0, 1, 0, 1] }}
                transition={{ duration: 0.5, delay: 0.2, times: [0, 0.2, 0.4, 0.6, 0.8, 1] }}
              >
                a
              </motion.span>
            </div>
          </motion.div>
        </motion.div>
      </div>
    )
  }

  // Third phase - Particle explosion and final reveal
  if (phase === 2) {
    return (
      <div className="flex flex-col items-center justify-center">
        <div className="relative">
          <motion.div
            initial={{ scale: 1 }}
            animate={{
              scale: [1, 1.5, 0.8, 1.2, 1],
              filter: ["blur(0px)", "blur(4px)", "blur(0px)", "blur(2px)", "blur(0px)"],
            }}
            transition={{ duration: 1.5, ease: "easeInOut" }}
            className="text-8xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-emerald-500 to-cyan-500 cyber-glow"
          >
            9am
          </motion.div>

          {/* Particle explosion */}
          {particles.map((particle, index) => (
            <motion.div
              key={index}
              className="absolute top-1/2 left-1/2 rounded-full"
              initial={{
                x: 0,
                y: 0,
                opacity: 0,
                width: 0,
                height: 0,
                backgroundColor: particle.color,
              }}
              animate={{
                x: particle.x,
                y: particle.y,
                opacity: [0, 1, 0],
                width: particle.size,
                height: particle.size,
              }}
              transition={{
                duration: 1.5,
                delay: particle.delay,
                ease: "easeOut",
              }}
            />
          ))}

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.5 }}
            className="absolute top-full left-1/2 transform -translate-x-1/2 mt-4"
          >
            <motion.div
              className="text-2xl font-bold"
              animate={{
                color: ["#9333ea", "#ec4899", "#9333ea", "#ec4899"],
                textShadow: [
                  "0 0 5px rgba(147, 51, 234, 0.5), 0 0 10px rgba(147, 51, 234, 0.3)",
                  "0 0 5px rgba(236, 72, 153, 0.5), 0 0 10px rgba(236, 72, 153, 0.3)",
                  "0 0 5px rgba(147, 51, 234, 0.5), 0 0 10px rgba(147, 51, 234, 0.3)",
                  "0 0 5px rgba(236, 72, 153, 0.5), 0 0 10px rgba(236, 72, 153, 0.3)",
                ],
              }}
              transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
            >
              aka
            </motion.div>
          </motion.div>
        </div>
      </div>
    )
  }

  // Final phase - Fade out
  return (
    <div className="flex flex-col items-center justify-center">
      <motion.div
        initial={{ opacity: 1, scale: 1 }}
        animate={{
          opacity: 0,
          scale: 1.5,
          filter: "blur(10px)",
        }}
        transition={{ duration: 1 }}
        className="text-8xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-emerald-500 to-cyan-500 cyber-glow"
      >
        9am
      </motion.div>

      <motion.div
        initial={{ opacity: 1 }}
        animate={{ opacity: 0 }}
        transition={{ duration: 0.5 }}
        className="mt-4 text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-500 to-pink-500"
      >
        aka
      </motion.div>
    </div>
  )
}

