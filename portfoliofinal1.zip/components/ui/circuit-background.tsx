"use client"

import { useEffect, useRef } from "react"

export function CircuitBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    canvas.width = window.innerWidth
    canvas.height = window.innerHeight

    const nodeCount = Math.floor((canvas.width * canvas.height) / 50000)
    const nodes: Node[] = []

    class Node {
      x: number
      y: number
      connections: number[]

      constructor(x: number, y: number) {
        this.x = x
        this.y = y
        this.connections = []
      }
    }

    function createNodes() {
      for (let i = 0; i < nodeCount; i++) {
        const x = Math.random() * canvas.width
        const y = Math.random() * canvas.height
        nodes.push(new Node(x, y))
      }

      // Create connections
      for (let i = 0; i < nodes.length; i++) {
        const node = nodes[i]

        // Find closest nodes
        const distances: { index: number; distance: number }[] = []

        for (let j = 0; j < nodes.length; j++) {
          if (i === j) continue

          const otherNode = nodes[j]
          const dx = node.x - otherNode.x
          const dy = node.y - otherNode.y
          const distance = Math.sqrt(dx * dx + dy * dy)

          if (distance < 300) {
            distances.push({ index: j, distance })
          }
        }

        // Sort by distance and take closest 2-3
        distances.sort((a, b) => a.distance - b.distance)
        const connectionCount = Math.floor(Math.random() * 2) + 1 // 1-2 connections

        for (let k = 0; k < Math.min(connectionCount, distances.length); k++) {
          node.connections.push(distances[k].index)
        }
      }
    }

    function drawCircuit() {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Draw connections
      for (let i = 0; i < nodes.length; i++) {
        const node = nodes[i]

        for (const connectionIndex of node.connections) {
          const connectedNode = nodes[connectionIndex]

          ctx.beginPath()
          ctx.moveTo(node.x, node.y)
          ctx.lineTo(connectedNode.x, connectedNode.y)
          ctx.strokeStyle = "rgba(0, 255, 170, 0.1)"
          ctx.lineWidth = 1
          ctx.stroke()
        }
      }

      // Draw nodes
      for (const node of nodes) {
        ctx.beginPath()
        ctx.arc(node.x, node.y, 2, 0, Math.PI * 2)
        ctx.fillStyle = "rgba(0, 255, 170, 0.5)"
        ctx.fill()
      }
    }

    createNodes()
    drawCircuit()

    const handleResize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
      nodes.length = 0
      createNodes()
      drawCircuit()
    }

    window.addEventListener("resize", handleResize)

    return () => {
      window.removeEventListener("resize", handleResize)
    }
  }, [])

  return <canvas ref={canvasRef} className="fixed inset-0 z-0 opacity-10" />
}

