"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"

interface GlitchTextProps {
  text: string
  className?: string
  glitchInterval?: number
  glitchDuration?: number
}

export function GlitchText({ text, className = "", glitchInterval = 5000, glitchDuration = 200 }: GlitchTextProps) {
  const [isGlitching, setIsGlitching] = useState(false)

  useEffect(() => {
    const intervalId = setInterval(() => {
      setIsGlitching(true)

      setTimeout(() => {
        setIsGlitching(false)
      }, glitchDuration)
    }, glitchInterval)

    return () => clearInterval(intervalId)
  }, [glitchInterval, glitchDuration])

  return (
    <div className={`relative inline-block ${className}`}>
      <span className="relative z-10">{text}</span>

      {isGlitching && (
        <>
          <motion.span
            initial={{ opacity: 0, x: -2, y: 0 }}
            animate={{ opacity: [0, 1, 0.5, 1, 0], x: [-2, 1, -1, 0, -1], y: [0, 1, -1, 1, 0] }}
            transition={{ duration: glitchDuration / 1000, ease: "easeInOut" }}
            className="absolute inset-0 text-red-500 z-0"
            style={{ clipPath: "polygon(0 15%, 100% 15%, 100% 40%, 0 40%)" }}
          >
            {text}
          </motion.span>

          <motion.span
            initial={{ opacity: 0, x: 2, y: 0 }}
            animate={{ opacity: [0, 1, 0.5, 1, 0], x: [2, -1, 1, 0, 1], y: [0, -1, 1, -1, 0] }}
            transition={{ duration: glitchDuration / 1000, ease: "easeInOut" }}
            className="absolute inset-0 text-cyan-500 z-0"
            style={{ clipPath: "polygon(0 65%, 100% 65%, 100% 90%, 0 90%)" }}
          >
            {text}
          </motion.span>
        </>
      )}
    </div>
  )
}

