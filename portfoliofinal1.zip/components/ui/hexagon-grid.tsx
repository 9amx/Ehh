"use client"

import { useEffect, useRef } from "react"

export function HexagonGrid() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    canvas.width = window.innerWidth
    canvas.height = window.innerHeight

    const hexSize = 30
    const hexHeight = hexSize * Math.sqrt(3)
    const hexWidth = hexSize * 2
    const hexVerticalDistance = hexHeight
    const hexHorizontalDistance = hexWidth * 0.75

    function drawHexagon(x: number, y: number, size: number) {
      ctx.beginPath()
      for (let i = 0; i < 6; i++) {
        const angle = (Math.PI / 3) * i
        const xPos = x + size * Math.cos(angle)
        const yPos = y + size * Math.sin(angle)

        if (i === 0) {
          ctx.moveTo(xPos, yPos)
        } else {
          ctx.lineTo(xPos, yPos)
        }
      }
      ctx.closePath()

      // Random opacity for each hexagon
      const opacity = Math.random() * 0.1 + 0.02
      ctx.strokeStyle = `rgba(0, 255, 170, ${opacity})`
      ctx.lineWidth = 1
      ctx.stroke()
    }

    function drawGrid() {
      const rows = Math.ceil(canvas.height / hexVerticalDistance) + 2
      const cols = Math.ceil(canvas.width / hexHorizontalDistance) + 2

      for (let row = -1; row < rows; row++) {
        for (let col = -1; col < cols; col++) {
          const x = col * hexHorizontalDistance + (row % 2 === 0 ? 0 : hexHorizontalDistance / 2)
          const y = row * hexVerticalDistance

          drawHexagon(x, y, hexSize)
        }
      }
    }

    drawGrid()

    const handleResize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
      drawGrid()
    }

    window.addEventListener("resize", handleResize)

    return () => {
      window.removeEventListener("resize", handleResize)
    }
  }, [])

  return <canvas ref={canvasRef} className="absolute inset-0 z-0" />
}

