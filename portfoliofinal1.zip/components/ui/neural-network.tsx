"use client"

import { useEffect, useRef } from "react"

interface Node {
  x: number
  y: number
  vx: number
  vy: number
  radius: number
}

export function NeuralNetwork() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    canvas.width = window.innerWidth
    canvas.height = window.innerHeight

    const nodes: Node[] = []
    // Reduce the number of nodes and connections by 50%
    const nodeCount = Math.min(40, Math.floor((canvas.width * canvas.height) / 30000)) // Reduced from 80 and 15000
    // Reduce the connection distance to decrease the number of connections
    const connectionDistance = 100 // Reduced from 150

    // Create nodes
    for (let i = 0; i < nodeCount; i++) {
      nodes.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
        radius: Math.random() * 2 + 1,
      })
    }

    function drawNetwork() {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Update node positions
      nodes.forEach((node) => {
        node.x += node.vx
        node.y += node.vy

        // Bounce off edges
        if (node.x < 0 || node.x > canvas.width) node.vx *= -1
        if (node.y < 0 || node.y > canvas.height) node.vy *= -1

        // Draw node
        ctx.beginPath()
        ctx.arc(node.x, node.y, node.radius, 0, Math.PI * 2)
        ctx.fillStyle = "rgba(0, 255, 170, 0.6)"
        ctx.fill()
      })

      // Draw connections
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = nodes[i].x - nodes[j].x
          const dy = nodes[i].y - nodes[j].y
          const distance = Math.sqrt(dx * dx + dy * dy)

          if (distance < connectionDistance) {
            // Calculate opacity based on distance
            const opacity = 1 - distance / connectionDistance

            // Draw connection line
            ctx.beginPath()
            ctx.moveTo(nodes[i].x, nodes[i].y)
            ctx.lineTo(nodes[j].x, nodes[j].y)
            ctx.strokeStyle = `rgba(0, 255, 170, ${opacity * 0.2})`
            ctx.lineWidth = 1
            ctx.stroke()

            // Draw data pulse animation along the line
            if (Math.random() > 0.99) {
              animateDataPulse(nodes[i].x, nodes[i].y, nodes[j].x, nodes[j].y)
            }
          }
        }
      }

      requestAnimationFrame(drawNetwork)
    }

    const pulses: { x: number; y: number; tx: number; ty: number; progress: number }[] = []

    function animateDataPulse(x1: number, y1: number, x2: number, y2: number) {
      pulses.push({
        x: x1,
        y: y1,
        tx: x2,
        ty: y2,
        progress: 0,
      })
    }

    function updatePulses() {
      for (let i = pulses.length - 1; i >= 0; i--) {
        const pulse = pulses[i]

        // Update progress
        pulse.progress += 0.02

        if (pulse.progress >= 1) {
          pulses.splice(i, 1)
          continue
        }

        // Calculate current position
        const x = pulse.x + (pulse.tx - pulse.x) * pulse.progress
        const y = pulse.y + (pulse.ty - pulse.y) * pulse.progress

        // Draw pulse
        ctx.beginPath()
        ctx.arc(x, y, 2, 0, Math.PI * 2)
        ctx.fillStyle = "rgba(0, 255, 255, 0.8)"
        ctx.fill()
      }
    }

    function animate() {
      drawNetwork()
      updatePulses()
      requestAnimationFrame(animate)
    }

    animate()

    const handleResize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    window.addEventListener("resize", handleResize)

    return () => {
      window.removeEventListener("resize", handleResize)
    }
  }, [])

  return <canvas ref={canvasRef} className="fixed inset-0 z-0 opacity-30" />
}

