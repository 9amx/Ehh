"use client"

// Enhance the platform badges to make them more prominent

import { motion } from "framer-motion"
import { Bug, Shield, Lock } from "lucide-react"

interface PlatformBadge {
  name: string
  color: string
  textColor: string
  bgColor: string
  icon: JSX.Element
}

export function PlatformBadges() {
  const platforms: PlatformBadge[] = [
    {
      name: "HackerOne",
      color: "border-red-500/50",
      textColor: "text-red-400",
      bgColor: "bg-red-900/20",
      icon: <Bug className="w-4 h-4 mr-2" />,
    },
    {
      name: "Yes We Hack",
      color: "border-yellow-500/50",
      textColor: "text-yellow-400",
      bgColor: "bg-yellow-900/20",
      icon: <Shield className="w-4 h-4 mr-2" />,
    },
    {
      name: "Bugcrowd",
      color: "border-orange-500/50",
      textColor: "text-orange-400",
      bgColor: "bg-orange-900/20",
      icon: <Bug className="w-4 h-4 mr-2" />,
    },
    {
      name: "Intigriti",
      color: "border-blue-500/50",
      textColor: "text-blue-400",
      bgColor: "bg-blue-900/20",
      icon: <Lock className="w-4 h-4 mr-2" />,
    },
  ]

  return (
    <div className="mt-8">
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center mb-3 font-mono text-sm text-gray-400"
      >
        <span className="text-emerald-500">{">"}</span> Security Researcher at:
      </motion.div>

      <div className="flex flex-wrap justify-center gap-3">
        {platforms.map((platform, index) => (
          <motion.div
            key={platform.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.1 * index }}
            className={`px-4 py-2 rounded-md ${platform.bgColor} border ${platform.color} font-mono text-sm flex items-center`}
            whileHover={{
              scale: 1.05,
              boxShadow: `0 0 15px rgba(0, 255, 170, 0.3)`,
            }}
          >
            <span className={platform.textColor}>{platform.icon}</span>
            <span className={platform.textColor}>{platform.name}</span>
          </motion.div>
        ))}
      </div>
    </div>
  )
}

