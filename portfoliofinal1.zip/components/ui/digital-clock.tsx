"use client"

import { useState, useEffect } from "react"

interface DigitalClockProps {
  className?: string
}

export function DigitalClock({ className = "" }: DigitalClockProps) {
  const [time, setTime] = useState("")

  useEffect(() => {
    const updateTime = () => {
      const now = new Date()
      const hours = now.getHours().toString().padStart(2, "0")
      const minutes = now.getMinutes().toString().padStart(2, "0")
      const seconds = now.getSeconds().toString().padStart(2, "0")

      setTime(`${hours}:${minutes}:${seconds}`)
    }

    updateTime()
    const interval = setInterval(updateTime, 1000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className={`font-mono ${className}`}>
      <span className="text-emerald-500">[</span>
      {time}
      <span className="text-emerald-500">]</span>
    </div>
  )
}

