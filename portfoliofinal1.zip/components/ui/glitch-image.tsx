"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { motion } from "framer-motion"

interface GlitchImageProps {
  src: string
  alt: string
  width: number
  height: number
  className?: string
  glitchInterval?: number
}

export function GlitchImage({ src, alt, width, height, className = "", glitchInterval = 5000 }: GlitchImageProps) {
  const [isGlitching, setIsGlitching] = useState(false)

  useEffect(() => {
    const intervalId = setInterval(() => {
      setIsGlitching(true)

      setTimeout(() => {
        setIsGlitching(false)
      }, 500)
    }, glitchInterval)

    return () => clearInterval(intervalId)
  }, [glitchInterval])

  return (
    <div className={`relative overflow-hidden ${className}`}>
      <Image src={src || "/placeholder.svg"} alt={alt} width={width} height={height} className="w-full h-auto" />

      {isGlitching && (
        <>
          <motion.div
            initial={{ opacity: 0, x: -5 }}
            animate={{
              opacity: [0, 1, 0.5, 1, 0],
              x: [-5, 0, -3, 0, -5],
            }}
            transition={{ duration: 0.5, ease: "easeInOut" }}
            className="absolute inset-0 bg-red-500 mix-blend-screen z-10"
            style={{ clipPath: "polygon(0 15%, 100% 15%, 100% 40%, 0 40%)" }}
          />

          <motion.div
            initial={{ opacity: 0, x: 5 }}
            animate={{
              opacity: [0, 1, 0.5, 1, 0],
              x: [5, 0, 3, 0, 5],
            }}
            transition={{ duration: 0.5, ease: "easeInOut" }}
            className="absolute inset-0 bg-cyan-500 mix-blend-screen z-10"
            style={{ clipPath: "polygon(0 65%, 100% 65%, 100% 80%, 0 80%)" }}
          />

          <motion.div
            initial={{ opacity: 0 }}
            animate={{
              opacity: [0, 0.5, 0, 0.5, 0],
            }}
            transition={{ duration: 0.5, ease: "easeInOut" }}
            className="absolute inset-0 bg-white mix-blend-overlay z-10"
            style={{
              clipPath:
                "polygon(0 10%, 100% 10%, 100% 15%, 0 15%, 0 40%, 100% 40%, 100% 45%, 0 45%, 0 70%, 100% 70%, 100% 75%, 0 75%)",
            }}
          />
        </>
      )}
    </div>
  )
}

