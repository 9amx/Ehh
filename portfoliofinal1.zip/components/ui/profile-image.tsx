"use client"

import { useState, useEffect, useRef } from "react"
import Image from "next/image"
import { motion } from "framer-motion"

interface ProfileImageProps {
  className?: string
}

export function ProfileImage({ className = "" }: ProfileImageProps) {
  const [glitchActive, setGlitchActive] = useState(false)
  const [hoverState, setHoverState] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)

  // Trigger glitch effect periodically
  useEffect(() => {
    const glitchInterval = setInterval(() => {
      if (Math.random() > 0.7) {
        setGlitchActive(true)
        setTimeout(() => setGlitchActive(false), 300)
      }
    }, 3000)
    return () => clearInterval(glitchInterval)
  }, [])

  // Matrix-like effect for the border
  useEffect(() => {
    if (!containerRef.current || !hoverState) return

    const canvas = document.createElement("canvas")
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    canvas.width = 300
    canvas.height = 300
    canvas.style.position = "absolute"
    canvas.style.top = "0"
    canvas.style.left = "0"
    canvas.style.pointerEvents = "none"
    canvas.style.zIndex = "20"

    containerRef.current.appendChild(canvas)

    const characters = "01アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン"
    const fontSize = 10
    const columns = canvas.width / fontSize

    const drops: number[] = []
    for (let i = 0; i < columns; i++) {
      drops[i] = 1
    }

    const draw = () => {
      ctx.fillStyle = "rgba(0, 0, 0, 0.05)"
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      ctx.fillStyle = "#0f0"
      ctx.font = `${fontSize}px monospace`

      for (let i = 0; i < drops.length; i++) {
        const text = characters.charAt(Math.floor(Math.random() * characters.length))

        // Only draw characters along the border
        const x = i * fontSize
        const y = drops[i] * fontSize

        // Check if this position is on the border (with some thickness)
        const borderThickness = 20
        const isOnBorder =
          x < borderThickness ||
          x > canvas.width - borderThickness ||
          y < borderThickness ||
          y > canvas.height - borderThickness

        if (isOnBorder) {
          ctx.fillText(text, x, y)
        }

        if (y > canvas.height && Math.random() > 0.975) {
          drops[i] = 0
        }

        drops[i]++
      }
    }

    const interval = setInterval(draw, 33)

    return () => {
      clearInterval(interval)
      if (containerRef.current && containerRef.current.contains(canvas)) {
        containerRef.current.removeChild(canvas)
      }
    }
  }, [hoverState])

  return (
    <motion.div
      ref={containerRef}
      className={`relative ${className}`}
      onHoverStart={() => setHoverState(true)}
      onHoverEnd={() => setHoverState(false)}
      whileHover={{ scale: 1.05 }}
      transition={{ duration: 0.3 }}
    >
      {/* Border container */}
      <div className="relative border-4 border-emerald-500/50 overflow-hidden">
        {/* Main image */}
        <div className="relative z-10">
          <Image src="/profile-image.png" alt="9am Profile" width={300} height={300} className="w-full h-auto" />

          {/* Overlay with cyberpunk grid */}
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/50 z-10"></div>

          {/* Grid overlay */}
          <div className="absolute inset-0 bg-[linear-gradient(0deg,rgba(0,255,170,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(0,255,170,0.1)_1px,transparent_1px)] bg-[size:20px_20px] z-20 opacity-30"></div>

          {/* Corner accents */}
          <div className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-emerald-500 z-20"></div>
          <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-emerald-500 z-20"></div>
          <div className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-emerald-500 z-20"></div>
          <div className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-emerald-500 z-20"></div>

          {/* Scan line effect */}
          <motion.div
            className="absolute left-0 right-0 h-[2px] bg-cyan-500/50 z-30"
            initial={{ top: "-10%" }}
            animate={{ top: ["0%", "100%"] }}
            transition={{
              duration: 2,
              repeat: Number.POSITIVE_INFINITY,
              ease: "linear",
              repeatType: "loop",
            }}
          />

          {/* Horizontal scan line */}
          <motion.div
            className="absolute top-0 bottom-0 w-[2px] bg-emerald-500/50 z-30"
            initial={{ left: "-10%" }}
            animate={{ left: ["0%", "100%"] }}
            transition={{
              duration: 3,
              repeat: Number.POSITIVE_INFINITY,
              ease: "linear",
              repeatType: "loop",
            }}
          />
        </div>

        {/* Glitch effects */}
        {glitchActive && (
          <>
            <motion.div
              initial={{ opacity: 0, x: -5 }}
              animate={{
                opacity: [0, 1, 0.5, 1, 0],
                x: [-5, 0, -3, 0, -5],
              }}
              transition={{ duration: 0.5, ease: "easeInOut" }}
              className="absolute inset-0 bg-red-500/20 mix-blend-screen z-40"
              style={{ clipPath: "polygon(0 15%, 100% 15%, 100% 40%, 0 40%)" }}
            />

            <motion.div
              initial={{ opacity: 0, x: 5 }}
              animate={{
                opacity: [0, 1, 0.5, 1, 0],
                x: [5, 0, 3, 0, 5],
              }}
              transition={{ duration: 0.5, ease: "easeInOut" }}
              className="absolute inset-0 bg-cyan-500/20 mix-blend-screen z-40"
              style={{ clipPath: "polygon(0 65%, 100% 65%, 100% 80%, 0 80%)" }}
            />

            {/* Glitch lines */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: [0, 1, 0] }}
              transition={{ duration: 0.3 }}
              className="absolute inset-0 overflow-hidden z-40"
            >
              {Array.from({ length: 5 }).map((_, i) => (
                <div
                  key={i}
                  className="absolute h-[2px] bg-white/70"
                  style={{
                    top: `${Math.random() * 100}%`,
                    left: 0,
                    right: 0,
                    transform: `translateX(${Math.random() * 10 - 5}px)`,
                  }}
                />
              ))}
            </motion.div>
          </>
        )}

        {/* Data stream effect - only visible on hover */}
        {hoverState && (
          <div className="absolute inset-0 overflow-hidden z-30 pointer-events-none">
            {Array.from({ length: 10 }).map((_, i) => (
              <motion.div
                key={i}
                className="absolute text-[8px] font-mono text-emerald-500/70"
                initial={{
                  opacity: 0,
                  y: -10,
                  x: Math.random() * 300,
                }}
                animate={{
                  opacity: [0, 1, 0],
                  y: [0, 300],
                }}
                transition={{
                  duration: 1.5 + Math.random(),
                  repeat: Number.POSITIVE_INFINITY,
                  repeatDelay: Math.random() * 2,
                }}
              >
                {Math.random() > 0.5 ? "0" : "1"}
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* Glow effect on hover */}
      <motion.div
        className="absolute inset-0 z-0"
        initial={{ boxShadow: "0 0 0 rgba(0, 255, 170, 0)" }}
        animate={{
          boxShadow: hoverState ? "0 0 30px rgba(0, 255, 170, 0.7)" : "0 0 15px rgba(0, 255, 170, 0.3)",
        }}
        transition={{ duration: 0.3 }}
      />

      {/* Animated border */}
      <motion.div
        className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-500 to-cyan-500 z-50"
        initial={{ width: "30%" }}
        animate={{ width: hoverState ? "100%" : "30%" }}
        transition={{ duration: 0.3 }}
      />
      <motion.div
        className="absolute top-0 right-0 w-1 h-full bg-gradient-to-b from-cyan-500 to-purple-500 z-50"
        initial={{ height: "30%" }}
        animate={{ height: hoverState ? "100%" : "30%" }}
        transition={{ duration: 0.3 }}
      />
      <motion.div
        className="absolute bottom-0 right-0 w-full h-1 bg-gradient-to-l from-purple-500 to-emerald-500 z-50"
        initial={{ width: "30%" }}
        animate={{ width: hoverState ? "100%" : "30%" }}
        transition={{ duration: 0.3 }}
      />
      <motion.div
        className="absolute bottom-0 left-0 w-1 h-full bg-gradient-to-t from-emerald-500 to-cyan-500 z-50"
        initial={{ height: "30%" }}
        animate={{ height: hoverState ? "100%" : "30%" }}
        transition={{ duration: 0.3 }}
      />

      {/* Status indicator */}
      <div className="absolute -bottom-2 -right-2 w-4 h-4 bg-black rounded-full p-0.5 z-50">
        <motion.div
          className="w-full h-full rounded-full bg-emerald-500"
          animate={{
            opacity: [0.5, 1, 0.5],
            scale: [0.8, 1, 0.8],
          }}
          transition={{
            duration: 2,
            repeat: Number.POSITIVE_INFINITY,
          }}
        />
      </div>

      {/* Tech ID tag */}
      <motion.div
        className="absolute -top-2 -left-2 bg-black/80 border border-emerald-500/50 px-2 py-0.5 text-[10px] font-mono text-emerald-500 z-50"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        whileHover={{ scale: 1.1 }}
      >
        ID:9AM
      </motion.div>
    </motion.div>
  )
}

