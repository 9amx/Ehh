"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"

interface DynamicCodeDisplayProps {
  name: string
  alias: string
}

export function DynamicCodeDisplay({ name, alias }: DynamicCodeDisplayProps) {
  const [isAnimating, setIsAnimating] = useState(false)

  useEffect(() => {
    // Trigger animation periodically
    const interval = setInterval(() => {
      setIsAnimating(true)
      setTimeout(() => setIsAnimating(false), 3000)
    }, 10000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="relative font-mono text-lg md:text-2xl lg:text-3xl">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-8 items-center justify-items-center md:justify-items-start">
        {/* Left column */}
        <motion.div
          className="text-center md:text-left"
          animate={
            isAnimating
              ? {
                  x: [0, -10, 5, -5, 0],
                  filter: ["blur(0px)", "blur(2px)", "blur(0px)"],
                }
              : {}
          }
          transition={{ duration: 0.5 }}
        >
          <span className="text-purple-400">const</span> <br className="md:hidden" />
          <span className="text-blue-400">developer</span> <br className="md:hidden" />
          <span className="text-white">=</span> <br className="md:hidden" />
          <span className="text-orange-400">{"{"}</span>
        </motion.div>

        {/* Middle column */}
        <motion.div
          className="text-center"
          animate={
            isAnimating
              ? {
                  y: [0, -5, 5, 0],
                  scale: [1, 1.05, 0.98, 1],
                }
              : {}
          }
          transition={{ duration: 0.7, delay: 0.1 }}
        >
          <span className="text-green-400">name:</span> <br className="md:hidden" />
          <span className="text-yellow-300">"</span>
          <motion.span
            className="text-white font-bold"
            animate={
              isAnimating
                ? {
                    color: ["#ffffff", "#00ffaa", "#ffffff"],
                  }
                : {}
            }
            transition={{ duration: 1 }}
          >
            {name}
          </motion.span>
          <span className="text-yellow-300">"</span>
          <span className="text-white">,</span>
        </motion.div>

        {/* Right column */}
        <motion.div
          className="text-center md:text-left"
          animate={
            isAnimating
              ? {
                  x: [0, 10, -5, 5, 0],
                  filter: ["blur(0px)", "blur(2px)", "blur(0px)"],
                }
              : {}
          }
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <span className="text-green-400">alias:</span> <br className="md:hidden" />
          <span className="text-yellow-300">"</span>
          <motion.span
            className="text-cyan-400 font-bold"
            animate={
              isAnimating
                ? {
                    textShadow: [
                      "0 0 0px rgba(0,255,255,0)",
                      "0 0 10px rgba(0,255,255,0.8)",
                      "0 0 0px rgba(0,255,255,0)",
                    ],
                  }
                : {}
            }
            transition={{ duration: 1.2 }}
          >
            {alias}
          </motion.span>
          <span className="text-yellow-300">"</span> <br className="md:hidden" />
          <span className="text-orange-400">{"}"}</span>
          <span className="text-emerald-500">;</span>
        </motion.div>
      </div>

      {/* Animated code comments */}
      <motion.div
        className="absolute -top-12 left-0 right-0 text-xs md:text-sm text-emerald-500/70 font-mono text-center md:text-left"
        initial={{ opacity: 0, y: 5 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.0 }}
      >
        <motion.span
          animate={{
            opacity: [1, 0.5, 1],
          }}
          transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
        >
          // Cybersecurity Expert & Bug Hunter
        </motion.span>
      </motion.div>

      <motion.div
        className="absolute -bottom-12 left-0 right-0 text-xs md:text-sm text-emerald-500/70 font-mono text-center md:text-left"
        initial={{ opacity: 0, y: -5 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.2 }}
      >
        <motion.span
          animate={{
            opacity: [1, 0.5, 1],
          }}
          transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, repeatDelay: 1 }}
        >
          // Specializing in finding critical vulnerabilities
        </motion.span>
      </motion.div>

      {/* Animated brackets and symbols */}
      {isAnimating && (
        <>
          <motion.div
            className="absolute -left-4 top-1/2 transform -translate-y-1/2 text-orange-400/30 text-4xl"
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: [0, 1.5, 1] }}
            exit={{ opacity: 0, scale: 0 }}
            transition={{ duration: 0.5 }}
          >
            {"{"}
          </motion.div>
          <motion.div
            className="absolute -right-4 top-1/2 transform -translate-y-1/2 text-orange-400/30 text-4xl"
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: [0, 1.5, 1] }}
            exit={{ opacity: 0, scale: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            {"}"}
          </motion.div>
          <motion.div
            className="absolute top-0 left-1/4 text-emerald-500/20 text-2xl"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.4 }}
          >
            {"</>"}
          </motion.div>
          <motion.div
            className="absolute bottom-0 right-1/4 text-cyan-500/20 text-2xl"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            transition={{ duration: 0.4, delay: 0.2 }}
          >
            {"</>"}
          </motion.div>
        </>
      )}
    </div>
  )
}

