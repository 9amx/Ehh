"use client"

import { useEffect, useRef } from "react"

interface HolographicBackgroundProps {
  reduced?: boolean
}

export function HolographicBackground({ reduced = false }: HolographicBackgroundProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    canvas.width = window.innerWidth
    canvas.height = window.innerHeight

    // Create holographic grid effect
    const gridSize = reduced ? 150 : 100 // Larger grid size when reduced
    const lineWidth = 1

    function drawGrid() {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Create a gradient for the grid lines
      const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height)
      gradient.addColorStop(0, "rgba(0, 255, 170, 0.1)")
      gradient.addColorStop(0.5, "rgba(0, 150, 255, 0.1)")
      gradient.addColorStop(1, "rgba(120, 0, 255, 0.1)")

      ctx.strokeStyle = gradient
      ctx.lineWidth = lineWidth

      // Draw horizontal lines
      for (let y = 0; y < canvas.height; y += gridSize) {
        ctx.beginPath()
        ctx.moveTo(0, y)
        ctx.lineTo(canvas.width, y)
        ctx.stroke()
      }

      // Draw vertical lines
      for (let x = 0; x < canvas.width; x += gridSize) {
        ctx.beginPath()
        ctx.moveTo(x, 0)
        ctx.lineTo(x, canvas.height)
        ctx.stroke()
      }

      // Add some random "data points" at grid intersections - fewer when reduced
      if (!reduced) {
        ctx.fillStyle = "rgba(0, 255, 170, 0.5)"

        for (let x = 0; x < canvas.width; x += gridSize) {
          for (let y = 0; y < canvas.height; y += gridSize) {
            if (Math.random() > 0.97) {
              const size = Math.random() * 3 + 1
              ctx.beginPath()
              ctx.arc(x, y, size, 0, Math.PI * 2)
              ctx.fill()
            }
          }
        }
      }

      // Add some "scanning" effect - simpler when reduced
      if (!reduced) {
        const time = Date.now() / 1000
        const scanLineY = (Math.sin(time) * 0.5 + 0.5) * canvas.height

        ctx.strokeStyle = "rgba(0, 255, 170, 0.3)"
        ctx.lineWidth = 2
        ctx.beginPath()
        ctx.moveTo(0, scanLineY)
        ctx.lineTo(canvas.width, scanLineY)
        ctx.stroke()

        // Add a subtle glow around the scan line
        const gradient2 = ctx.createLinearGradient(0, scanLineY - 20, 0, scanLineY + 20)
        gradient2.addColorStop(0, "rgba(0, 255, 170, 0)")
        gradient2.addColorStop(0.5, "rgba(0, 255, 170, 0.1)")
        gradient2.addColorStop(1, "rgba(0, 255, 170, 0)")

        ctx.fillStyle = gradient2
        ctx.fillRect(0, scanLineY - 20, canvas.width, 40)
      }
    }

    function animate() {
      drawGrid()
      requestAnimationFrame(animate)
    }

    animate()

    const handleResize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    window.addEventListener("resize", handleResize)

    return () => {
      window.removeEventListener("resize", handleResize)
    }
  }, [reduced])

  return <canvas ref={canvasRef} className="fixed inset-0 z-0 opacity-20" />
}

