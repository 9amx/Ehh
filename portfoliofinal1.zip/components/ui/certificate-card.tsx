"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { motion } from "framer-motion"
import { Calendar, Clock, Award, Shield, CheckCircle, ExternalLink } from "lucide-react"

interface CertificateCardProps {
  title: string
  issuer: string
  date: string
  description: string
  imageUrl: string
  duration?: string
}

export function CertificateCard({ title, issuer, date, description, imageUrl, duration }: CertificateCardProps) {
  const [isFlipped, setIsFlipped] = useState(false)
  const [isHovered, setIsHovered] = useState(false)
  const [randomOffset, setRandomOffset] = useState({ x: 0, y: 0 })
  const [glitchActive, setGlitchActive] = useState(false)

  // Generate random offset for the card
  useEffect(() => {
    setRandomOffset({
      x: Math.random() * 4 - 2,
      y: Math.random() * 4 - 2,
    })
  }, [])

  // Trigger glitch effect periodically
  useEffect(() => {
    if (isHovered) {
      const interval = setInterval(() => {
        setGlitchActive(true)
        setTimeout(() => setGlitchActive(false), 200)
      }, 3000)

      return () => clearInterval(interval)
    }
  }, [isHovered])

  return (
    <div
      className="perspective-[1000px] h-[450px]" // Increased height to accommodate content
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <motion.div
        className="relative w-full h-full transition-all duration-500 preserve-3d"
        animate={{
          rotateY: isFlipped ? 180 : 0,
          x: isHovered ? randomOffset.x : 0,
          y: isHovered ? randomOffset.y : 0,
        }}
        transition={{ duration: 0.6 }}
      >
        {/* Front side */}
        <div className="absolute inset-0 backface-hidden cursor-pointer" onClick={() => setIsFlipped(true)}>
          <div className="h-full rounded-lg overflow-hidden bg-gray-900/80 backdrop-blur-sm border border-gray-800 relative">
            {/* Animated border effect */}
            <motion.div
              className="absolute inset-0 pointer-events-none"
              animate={{
                boxShadow: isHovered
                  ? "0 0 15px rgba(0, 255, 170, 0.5), inset 0 0 15px rgba(0, 255, 170, 0.3)"
                  : "0 0 0px rgba(0, 255, 170, 0), inset 0 0 0px rgba(0, 255, 170, 0)",
              }}
              transition={{ duration: 0.3 }}
            />

            {/* Top border */}
            <motion.div
              className="absolute top-0 left-0 h-1 bg-gradient-to-r from-emerald-500 to-cyan-500"
              initial={{ width: "30%" }}
              animate={{ width: isHovered ? "100%" : "30%" }}
              transition={{ duration: 0.3 }}
            />

            {/* Right border */}
            <motion.div
              className="absolute top-0 right-0 w-1 bg-gradient-to-b from-cyan-500 to-purple-500"
              initial={{ height: "30%" }}
              animate={{ height: isHovered ? "100%" : "30%" }}
              transition={{ duration: 0.3 }}
            />

            {/* Bottom border */}
            <motion.div
              className="absolute bottom-0 right-0 h-1 bg-gradient-to-l from-purple-500 to-emerald-500"
              initial={{ width: "30%" }}
              animate={{ width: isHovered ? "100%" : "30%" }}
              transition={{ duration: 0.3 }}
            />

            {/* Left border */}
            <motion.div
              className="absolute bottom-0 left-0 w-1 bg-gradient-to-t from-emerald-500 to-cyan-500"
              initial={{ height: "30%" }}
              animate={{ height: isHovered ? "100%" : "30%" }}
              transition={{ duration: 0.3 }}
            />

            <div className="p-4 h-full flex flex-col">
              <div className="relative w-full h-48 mb-4 overflow-hidden rounded-md border border-gray-800 group">
                <Image
                  src={imageUrl || "/placeholder.svg"}
                  alt={title}
                  fill
                  className="object-cover transition-transform duration-700 group-hover:scale-110"
                />

                {/* Overlay gradient */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent" />

                {/* Scan line effect */}
                <motion.div
                  className="absolute left-0 right-0 h-[2px] bg-cyan-500/50"
                  initial={{ top: "-10%" }}
                  animate={{ top: ["0%", "100%"] }}
                  transition={{
                    duration: 2,
                    repeat: Number.POSITIVE_INFINITY,
                    ease: "linear",
                    repeatType: "loop",
                  }}
                />

                {/* Glitch effect */}
                {glitchActive && (
                  <>
                    <div
                      className="absolute inset-0 bg-red-500/10 mix-blend-screen"
                      style={{ clipPath: "polygon(0 15%, 100% 15%, 100% 40%, 0 40%)" }}
                    />
                    <div
                      className="absolute inset-0 bg-cyan-500/10 mix-blend-screen"
                      style={{ clipPath: "polygon(0 65%, 100% 65%, 100% 80%, 0 80%)" }}
                    />
                  </>
                )}

                {/* Certificate badge */}
                <div className="absolute top-2 right-2 bg-emerald-500/90 text-black text-xs font-bold px-2 py-1 rounded-full flex items-center">
                  <Shield className="w-3 h-3 mr-1" />
                  <span>CERTIFIED</span>
                </div>

                <div className="absolute bottom-2 left-2 right-2">
                  <motion.p className="text-xs text-emerald-400" animate={{ opacity: isHovered ? 1 : 0.7 }}>
                    Click to view details
                  </motion.p>
                </div>
              </div>

              <h3 className="text-lg font-bold mb-2 line-clamp-2 text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-400">
                {title}
              </h3>

              <div className="flex items-center text-sm text-gray-400 mb-2">
                <Award className="w-4 h-4 mr-1 text-emerald-500" />
                <span>{issuer}</span>
              </div>

              {/* Brief description preview - limited to 2 lines */}
              <p className="text-xs text-gray-400 line-clamp-2 mb-2">{description}</p>

              <div className="mt-auto flex justify-between text-xs text-gray-500">
                <div className="flex items-center">
                  <Calendar className="w-3 h-3 mr-1" />
                  <span>{date}</span>
                </div>
                {duration && (
                  <div className="flex items-center">
                    <Clock className="w-3 h-3 mr-1" />
                    <span>{duration}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Back side */}
        <div
          className="absolute inset-0 backface-hidden rotateY-180 cursor-pointer"
          onClick={() => setIsFlipped(false)}
        >
          <div className="h-full rounded-lg overflow-hidden bg-gray-900/80 backdrop-blur-sm border border-gray-800 relative">
            {/* Animated border effect (same as front) */}
            <motion.div
              className="absolute inset-0 pointer-events-none"
              animate={{
                boxShadow: isHovered
                  ? "0 0 15px rgba(0, 255, 170, 0.5), inset 0 0 15px rgba(0, 255, 170, 0.3)"
                  : "0 0 0px rgba(0, 255, 170, 0), inset 0 0 0px rgba(0, 255, 170, 0)",
              }}
              transition={{ duration: 0.3 }}
            />

            {/* Borders (same as front) */}
            <motion.div
              className="absolute top-0 left-0 h-1 bg-gradient-to-r from-emerald-500 to-cyan-500"
              initial={{ width: "30%" }}
              animate={{ width: isHovered ? "100%" : "30%" }}
              transition={{ duration: 0.3 }}
            />
            <motion.div
              className="absolute top-0 right-0 w-1 bg-gradient-to-b from-cyan-500 to-purple-500"
              initial={{ height: "30%" }}
              animate={{ height: isHovered ? "100%" : "30%" }}
              transition={{ duration: 0.3 }}
            />
            <motion.div
              className="absolute bottom-0 right-0 h-1 bg-gradient-to-l from-purple-500 to-emerald-500"
              initial={{ width: "30%" }}
              animate={{ width: isHovered ? "100%" : "30%" }}
              transition={{ duration: 0.3 }}
            />
            <motion.div
              className="absolute bottom-0 left-0 w-1 bg-gradient-to-t from-emerald-500 to-cyan-500"
              initial={{ height: "30%" }}
              animate={{ height: isHovered ? "100%" : "30%" }}
              transition={{ duration: 0.3 }}
            />

            <div className="p-6 h-full flex flex-col overflow-y-auto">
              {/* Circuit pattern background */}
              <div className="absolute inset-0 opacity-5 pointer-events-none">
                <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
                  <pattern id="circuit" width="100" height="100" patternUnits="userSpaceOnUse">
                    <path d="M10,10 L90,10 L90,90 L10,90 Z" fill="none" stroke="currentColor" strokeWidth="0.5" />
                    <circle cx="10" cy="10" r="2" fill="currentColor" />
                    <circle cx="90" cy="10" r="2" fill="currentColor" />
                    <circle cx="90" cy="90" r="2" fill="currentColor" />
                    <circle cx="10" cy="90" r="2" fill="currentColor" />
                    <path
                      d="M10,50 L40,50 M60,50 L90,50 M50,10 L50,40 M50,60 L50,90"
                      stroke="currentColor"
                      strokeWidth="0.5"
                    />
                    <circle cx="50" cy="50" r="5" fill="none" stroke="currentColor" strokeWidth="0.5" />
                  </pattern>
                  <rect width="100%" height="100%" fill="url(#circuit)" />
                </svg>
              </div>

              <h3 className="text-xl font-bold mb-4 text-transparent bg-clip-text bg-gradient-to-r from-emerald-500 to-cyan-500">
                {title}
              </h3>

              <div className="space-y-4 mb-4 overflow-y-auto">
                <div className="bg-gray-800/50 rounded-md p-3 backdrop-blur-sm">
                  <h4 className="text-sm font-semibold text-gray-400 mb-1 flex items-center">
                    <Award className="w-3 h-3 mr-1 text-emerald-500" />
                    Issuer
                  </h4>
                  <p className="text-white">{issuer}</p>
                </div>

                <div className="bg-gray-800/50 rounded-md p-3 backdrop-blur-sm">
                  <h4 className="text-sm font-semibold text-gray-400 mb-1 flex items-center">
                    <Calendar className="w-3 h-3 mr-1 text-emerald-500" />
                    Date
                  </h4>
                  <p className="text-white">{date}</p>
                </div>

                {duration && (
                  <div className="bg-gray-800/50 rounded-md p-3 backdrop-blur-sm">
                    <h4 className="text-sm font-semibold text-gray-400 mb-1 flex items-center">
                      <Clock className="w-3 h-3 mr-1 text-emerald-500" />
                      Duration
                    </h4>
                    <p className="text-white">{duration}</p>
                  </div>
                )}

                <div className="bg-gray-800/50 rounded-md p-3 backdrop-blur-sm">
                  <h4 className="text-sm font-semibold text-gray-400 mb-1 flex items-center">
                    <CheckCircle className="w-3 h-3 mr-1 text-emerald-500" />
                    Description
                  </h4>
                  <p className="text-gray-300 text-sm max-h-24 overflow-y-auto pr-2">{description}</p>
                </div>
              </div>

              <div className="mt-auto text-center">
                <motion.button
                  className="text-xs flex items-center justify-center mx-auto text-emerald-400 hover:text-emerald-300 transition-colors"
                  whileHover={{ scale: 1.05 }}
                  onClick={(e) => {
                    e.stopPropagation()
                    setIsFlipped(false)
                  }}
                >
                  <ExternalLink className="w-3 h-3 mr-1" />
                  View certificate
                </motion.button>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  )
}

