"use client"

import type React from "react"
import { motion } from "framer-motion"
import { TypewriterEffect } from "./typewriter-effect"

interface CodeTextProps {
  children: React.ReactNode
  className?: string
}

export function CodeText({ children, className = "" }: CodeTextProps) {
  return (
    <div className={`font-mono relative ${className}`}>
      {/* Line numbers - hidden on mobile */}
      <motion.div
        className="absolute -left-12 top-0 bottom-0 text-xs text-gray-600 font-mono text-right pr-2 hidden md:block"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
      >
        <div>01</div>
        <div>02</div>
        <div>03</div>
      </motion.div>

      {/* Code syntax highlighting - stacked vertically on mobile */}
      <div className="flex flex-col md:flex-row md:items-center">
        <motion.div
          className="text-gray-500 mr-1 mb-1 md:mb-0"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <span className="text-purple-400">const</span> <span className="text-blue-400">developer</span>{" "}
          <span className="text-white">=</span> <span className="text-orange-400">{"{"}</span>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="mb-1 md:mb-0 md:mx-2"
        >
          <span className="text-green-400 mr-2">name:</span> <span className="text-yellow-300">"</span>
          {children}
          <span className="text-yellow-300">"</span>
          <span className="text-white">,</span>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="mb-1 md:mb-0"
        >
          <span className="text-green-400 mr-2">alias:</span> <span className="text-yellow-300">"</span>
          <span className="text-cyan-400">9am</span>
          <span className="text-yellow-300">"</span>
        </motion.div>

        <motion.div
          className="text-gray-500"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
        >
          <span className="text-orange-400">{"}"}</span>
          <span className="text-emerald-500">;</span>
        </motion.div>
      </div>

      {/* Code-like decoration - positioned better for mobile */}
      <motion.div
        className="text-xs text-emerald-500/70 font-mono text-left mt-4 md:mt-0 md:absolute md:-top-8 md:left-0"
        initial={{ opacity: 0, y: 5 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.0 }}
      >
        <TypewriterEffect text="// Cybersecurity Expert & Bug Hunter" speed={30} delay={500} />
      </motion.div>

      <motion.div
        className="text-xs text-emerald-500/70 font-mono text-left mt-2 md:mt-0 md:absolute md:-bottom-8 md:left-0"
        initial={{ opacity: 0, y: -5 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.2 }}
      >
        <TypewriterEffect text="// Specializing in finding critical vulnerabilities" speed={30} delay={2000} />
      </motion.div>
    </div>
  )
}

