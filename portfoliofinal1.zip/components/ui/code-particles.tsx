"use client"

import { useRef } from "react"
import { motion } from "framer-motion"

interface CodeParticle {
  id: number
  x: number
  y: number
  text: string
  size: number
  color: string
  duration: number
  delay: number
}

export function CodeParticles() {
  const containerRef = useRef<HTMLDivElement>(null)

  // Code snippets related to bug hunting and security
  const codeSnippets = [
    "XSS",
    "SQLi",
    "CSRF",
    "CVE",
    "RCE",
    "LFI",
    "<script>",
    "SELECT *",
    "UNION",
    "exec()",
    "curl -X",
    "nmap",
    "burp",
    "metasploit",
    "0day",
    "payload",
    "exploit",
    "buffer",
    "overflow",
    "injection",
    "bypass",
    "admin",
    "root",
    "/etc/passwd",
    "403",
    "500",
    "200 OK",
  ]

  // Security symbols
  const symbols = ["{", "}", "[", "]", "<", ">", "=", ":", ";", "$", "#", "@", "/*", "*/", "//"]

  // Generate random particles
  const generateParticles = (count: number): CodeParticle[] => {
    const particles: CodeParticle[] = []

    for (let i = 0; i < count; i++) {
      const isSymbol = Math.random() > 0.7
      const text = isSymbol
        ? symbols[Math.floor(Math.random() * symbols.length)]
        : codeSnippets[Math.floor(Math.random() * codeSnippets.length)]

      particles.push({
        id: i,
        x: Math.random() * 100,
        y: Math.random() * 100,
        text,
        size: Math.random() * 0.5 + 0.7, // Size multiplier
        color: getRandomColor(),
        duration: Math.random() * 20 + 10,
        delay: Math.random() * 5,
      })
    }

    return particles
  }

  const getRandomColor = () => {
    const colors = [
      "text-emerald-500",
      "text-cyan-500",
      "text-blue-500",
      "text-purple-500",
      "text-yellow-500",
      "text-red-500",
    ]
    return colors[Math.floor(Math.random() * colors.length)]
  }

  const particles = generateParticles(15) // Reduced number for performance

  return (
    <div ref={containerRef} className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {particles.map((particle) => (
        <motion.div
          key={particle.id}
          className={`absolute font-mono text-opacity-30 ${particle.color}`}
          style={{
            left: `${particle.x}%`,
            top: `${particle.y}%`,
            fontSize: `${Math.floor(particle.size * 16)}px`,
          }}
          initial={{ opacity: 0 }}
          animate={{
            opacity: [0, 0.7, 0],
            y: [0, -30],
            x: [0, Math.random() * 20 - 10],
          }}
          transition={{
            duration: particle.duration,
            delay: particle.delay,
            repeat: Number.POSITIVE_INFINITY,
            repeatDelay: Math.random() * 5,
          }}
        >
          {particle.text}
        </motion.div>
      ))}
    </div>
  )
}

