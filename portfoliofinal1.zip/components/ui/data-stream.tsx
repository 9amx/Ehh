"use client"

import { useEffect, useRef } from "react"

export function DataStream() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    canvas.width = window.innerWidth
    canvas.height = window.innerHeight

    // Reduce the number of streams by 50%
    const streamCount = 7 // Reduced from 15
    const streams: { x: number; y: number; length: number; speed: number; chars: string[] }[] = []

    // Create data streams
    for (let i = 0; i < streamCount; i++) {
      streams.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height - 300,
        length: Math.floor(Math.random() * 15) + 5,
        speed: Math.random() * 2 + 1,
        chars: [],
      })

      // Generate random characters for each stream
      for (let j = 0; j < streams[i].length; j++) {
        const charCode = Math.floor(Math.random() * 94) + 33 // ASCII printable characters
        streams[i].chars.push(String.fromCharCode(charCode))
      }
    }

    function drawStreams() {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      streams.forEach((stream) => {
        // Update stream position
        stream.y += stream.speed

        // Reset stream if it goes off screen
        if (stream.y > canvas.height + 100) {
          stream.y = -100
          stream.x = Math.random() * canvas.width

          // Regenerate characters
          for (let j = 0; j < stream.length; j++) {
            const charCode = Math.floor(Math.random() * 94) + 33
            stream.chars[j] = String.fromCharCode(charCode)
          }
        }

        // Draw characters in stream
        for (let j = 0; j < stream.length; j++) {
          const y = stream.y - j * 20

          if (y < canvas.height && y > 0) {
            // Create gradient for each character
            const opacity = 1 - j / stream.length
            ctx.fillStyle = `rgba(0, 255, 170, ${opacity})`
            ctx.font = "14px monospace"
            ctx.fillText(stream.chars[j], stream.x, y)

            // Randomly change characters
            if (Math.random() > 0.95) {
              const charCode = Math.floor(Math.random() * 94) + 33
              stream.chars[j] = String.fromCharCode(charCode)
            }
          }
        }
      })

      requestAnimationFrame(drawStreams)
    }

    drawStreams()

    const handleResize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    window.addEventListener("resize", handleResize)

    return () => {
      window.removeEventListener("resize", handleResize)
    }
  }, [])

  return <canvas ref={canvasRef} className="fixed inset-0 z-0 opacity-20" />
}

