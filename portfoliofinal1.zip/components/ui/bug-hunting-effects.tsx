"use client"

import { useEffect, useState, useRef } from "react"
import { motion } from "framer-motion"
import { Shield, AlertTriangle, CheckCircle, Bug, Code, Search, Database } from "lucide-react"

interface ScanEffect {
  id: number
  x: number
  y: number
  type: "scan" | "vulnerability" | "fixed" | "exploit" | "database" | "code" | "search"
  duration: number
  size?: number
}

interface VulnPopup {
  id: number
  x: number
  y: number
  type: string
  message: string
  duration: number
}

export function BugHuntingEffects() {
  const [effects, setEffects] = useState<ScanEffect[]>([])
  const [vulnPopups, setVulnPopups] = useState<VulnPopup[]>([])
  const [scanLines, setScanLines] = useState<{ id: number; y: number; width: number; speed: number }[]>([])
  const canvasRef = useRef<HTMLCanvasElement>(null)

  // Initialize canvas for binary effect
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    canvas.width = window.innerWidth
    canvas.height = window.innerHeight

    const binaryChars = "01"
    const fontSize = 10
    const columns = Math.floor(canvas.width / fontSize)
    const drops: number[] = []

    for (let i = 0; i < columns; i++) {
      drops[i] = Math.random() * -100
    }

    const drawBinary = () => {
      ctx.fillStyle = "rgba(0, 0, 0, 0.05)"
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      ctx.fillStyle = "rgba(0, 255, 170, 0.1)"
      ctx.font = `${fontSize}px monospace`

      for (let i = 0; i < drops.length; i++) {
        const text = binaryChars.charAt(Math.floor(Math.random() * binaryChars.length))
        ctx.fillText(text, i * fontSize, drops[i] * fontSize)

        if (drops[i] * fontSize > canvas.height && Math.random() > 0.99) {
          drops[i] = 0
        }

        drops[i]++
      }

      requestAnimationFrame(drawBinary)
    }

    drawBinary()

    const handleResize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    window.addEventListener("resize", handleResize)

    return () => {
      window.removeEventListener("resize", handleResize)
    }
  }, [])

  // Generate scan effects periodically
  useEffect(() => {
    // Generate new effects periodically
    const interval = setInterval(() => {
      if (effects.length < 8) {
        // Increased max concurrent effects
        const effectTypes = ["scan", "vulnerability", "fixed", "exploit", "database", "code", "search"]
        const type = effectTypes[Math.floor(Math.random() * effectTypes.length)] as ScanEffect["type"]

        const newEffect: ScanEffect = {
          id: Date.now() + Math.random(),
          x: Math.random() * 90 + 5, // Keep away from edges
          y: Math.random() * 90 + 5,
          type,
          duration: Math.random() * 3 + 2,
          size: Math.random() * 0.5 + 0.8, // Random size multiplier
        }

        setEffects((prev) => [...prev, newEffect])

        // Remove effect after it completes
        setTimeout(
          () => {
            setEffects((prev) => prev.filter((effect) => effect.id !== newEffect.id))

            // Sometimes generate a vulnerability popup after an effect
            if ((type === "vulnerability" || type === "exploit") && Math.random() > 0.5) {
              generateVulnPopup(newEffect.x, newEffect.y)
            }
          },
          newEffect.duration * 1000 + 500,
        )
      }
    }, 1000) // More frequent effects

    return () => clearInterval(interval)
  }, [effects])

  // Generate horizontal scan lines
  useEffect(() => {
    const interval = setInterval(() => {
      if (scanLines.length < 3) {
        const newScanLine = {
          id: Date.now(),
          y: Math.random() * 100,
          width: Math.random() * 30 + 70, // 70-100% width
          speed: Math.random() * 2 + 1,
        }

        setScanLines((prev) => [...prev, newScanLine])

        // Remove scan line after it completes
        setTimeout(() => {
          setScanLines((prev) => prev.filter((line) => line.id !== newScanLine.id))
        }, 4000)
      }
    }, 2000)

    return () => clearInterval(interval)
  }, [scanLines])

  // Generate vulnerability popup
  const generateVulnPopup = (x: number, y: number) => {
    const vulnTypes = [
      { type: "XSS", message: "Cross-Site Scripting detected" },
      { type: "SQLi", message: "SQL Injection vulnerability found" },
      { type: "RCE", message: "Remote Code Execution possible" },
      { type: "CSRF", message: "Cross-Site Request Forgery" },
      { type: "SSRF", message: "Server-Side Request Forgery" },
      { type: "LFI", message: "Local File Inclusion vulnerability" },
      { type: "IDOR", message: "Insecure Direct Object Reference" },
      { type: "XXE", message: "XML External Entity vulnerability" },
      { type: "Open Redirect", message: "Unvalidated redirect detected" },
      { type: "API Key Leak", message: "Exposed API credentials" },
    ]

    const selectedVuln = vulnTypes[Math.floor(Math.random() * vulnTypes.length)]

    const newPopup: VulnPopup = {
      id: Date.now(),
      x: x,
      y: y,
      type: selectedVuln.type,
      message: selectedVuln.message,
      duration: Math.random() * 2 + 3,
    }

    setVulnPopups((prev) => [...prev, newPopup])

    // Remove popup after duration
    setTimeout(() => {
      setVulnPopups((prev) => prev.filter((popup) => popup.id !== newPopup.id))
    }, newPopup.duration * 1000)
  }

  // Get icon based on effect type
  const getEffectIcon = (type: ScanEffect["type"]) => {
    switch (type) {
      case "scan":
        return <Shield className="w-6 h-6 text-emerald-500" />
      case "vulnerability":
        return <AlertTriangle className="w-6 h-6 text-red-500" />
      case "fixed":
        return <CheckCircle className="w-6 h-6 text-blue-500" />
      case "exploit":
        return <Bug className="w-6 h-6 text-yellow-500" />
      case "database":
        return <Database className="w-6 h-6 text-purple-500" />
      case "code":
        return <Code className="w-6 h-6 text-cyan-500" />
      case "search":
        return <Search className="w-6 h-6 text-orange-500" />
      default:
        return <Shield className="w-6 h-6 text-emerald-500" />
    }
  }

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {/* Binary rain canvas */}
      <canvas ref={canvasRef} className="fixed inset-0 z-0 opacity-10" />

      {/* Horizontal scan lines */}
      {scanLines.map((line) => (
        <motion.div
          key={line.id}
          className="absolute left-0 h-[1px] bg-emerald-500/30"
          style={{
            top: `${line.y}%`,
            width: `${line.width}%`,
          }}
          animate={{
            x: ["0%", "100%"],
            opacity: [0, 0.8, 0],
          }}
          transition={{
            duration: 4,
            ease: "linear",
            times: [0, 0.5, 1],
          }}
        />
      ))}

      {/* Scan effects */}
      {effects.map((effect) => (
        <motion.div
          key={effect.id}
          className="absolute"
          style={{
            left: `${effect.x}%`,
            top: `${effect.y}%`,
            transform: `scale(${effect.size || 1})`,
          }}
          initial={{ opacity: 0, scale: 0 }}
          animate={{
            opacity: [0, 1, 1, 0],
            scale: [0, 1, 1, 0],
          }}
          transition={{
            duration: effect.duration,
            times: [0, 0.2, 0.8, 1],
          }}
        >
          {effect.type === "scan" && (
            <div className="relative">
              <motion.div
                className="absolute inset-0 rounded-full bg-emerald-500/20"
                animate={{
                  scale: [1, 3],
                  opacity: [0.5, 0],
                }}
                transition={{
                  duration: effect.duration * 0.8,
                  repeat: 1,
                  repeatType: "reverse",
                }}
              />
              {getEffectIcon(effect.type)}
            </div>
          )}

          {effect.type === "vulnerability" && (
            <div className="relative">
              <motion.div
                className="absolute inset-0 rounded-full bg-red-500/20"
                animate={{
                  scale: [1, 2],
                  opacity: [0.5, 0],
                }}
                transition={{
                  duration: effect.duration * 0.6,
                  repeat: 2,
                  repeatType: "reverse",
                }}
              />
              {getEffectIcon(effect.type)}
              <motion.div
                className="absolute top-full left-1/2 transform -translate-x-1/2 mt-1 text-xs font-mono text-red-500"
                initial={{ opacity: 0, y: -5 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
              >
                Vulnerability!
              </motion.div>
            </div>
          )}

          {effect.type === "fixed" && (
            <div className="relative">
              <motion.div
                className="absolute inset-0 rounded-full bg-blue-500/20"
                animate={{
                  scale: [1, 2],
                  opacity: [0.5, 0],
                }}
                transition={{
                  duration: effect.duration * 0.7,
                }}
              />
              {getEffectIcon(effect.type)}
              <motion.div
                className="absolute top-full left-1/2 transform -translate-x-1/2 mt-1 text-xs font-mono text-blue-500"
                initial={{ opacity: 0, y: -5 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
              >
                Patched!
              </motion.div>
            </div>
          )}

          {effect.type === "exploit" && (
            <div className="relative">
              <motion.div
                className="absolute inset-0 rounded-full bg-yellow-500/20"
                animate={{
                  scale: [1, 2.5],
                  opacity: [0.5, 0],
                }}
                transition={{
                  duration: effect.duration * 0.5,
                  repeat: 3,
                  repeatType: "reverse",
                }}
              />
              {getEffectIcon(effect.type)}
              <motion.div
                className="absolute top-full left-1/2 transform -translate-x-1/2 mt-1 text-xs font-mono text-yellow-500"
                initial={{ opacity: 0, y: -5 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
              >
                Exploited!
              </motion.div>
            </div>
          )}

          {(effect.type === "database" || effect.type === "code" || effect.type === "search") && (
            <div className="relative">
              <motion.div
                className={`absolute inset-0 rounded-full ${
                  effect.type === "database"
                    ? "bg-purple-500/20"
                    : effect.type === "code"
                      ? "bg-cyan-500/20"
                      : "bg-orange-500/20"
                }`}
                animate={{
                  scale: [1, 2],
                  opacity: [0.5, 0],
                }}
                transition={{
                  duration: effect.duration * 0.7,
                }}
              />
              {getEffectIcon(effect.type)}
            </div>
          )}
        </motion.div>
      ))}

      {/* Vulnerability popups */}
      {vulnPopups.map((popup) => (
        <motion.div
          key={popup.id}
          className="absolute bg-black/80 border border-red-500 rounded-md p-2 z-10"
          style={{
            left: `${popup.x}%`,
            top: `${popup.y}%`,
            transform: "translate(-50%, -50%)",
          }}
          initial={{ opacity: 0, scale: 0.8, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.8, y: 10 }}
          transition={{ duration: 0.3 }}
        >
          <div className="flex items-center text-red-500 font-mono text-xs mb-1">
            <AlertTriangle className="w-3 h-3 mr-1" />
            <span className="font-bold">{popup.type}</span>
          </div>
          <div className="text-gray-300 text-xs">{popup.message}</div>
        </motion.div>
      ))}

      {/* Occasional code snippets */}
      <motion.div
        className="fixed bottom-10 left-10 bg-black/50 border border-emerald-500/30 rounded p-2 font-mono text-xs text-emerald-500 max-w-xs"
        initial={{ opacity: 0 }}
        animate={{
          opacity: [0, 0.7, 0],
          x: [0, 20, 0],
        }}
        transition={{
          duration: 8,
          repeat: Number.POSITIVE_INFINITY,
          repeatDelay: 15,
        }}
      >
        <div>{"<script>alert(document.cookie)</script>"}</div>
      </motion.div>

      <motion.div
        className="fixed top-20 right-10 bg-black/50 border border-red-500/30 rounded p-2 font-mono text-xs text-red-500 max-w-xs"
        initial={{ opacity: 0 }}
        animate={{
          opacity: [0, 0.7, 0],
          x: [0, -20, 0],
        }}
        transition={{
          duration: 8,
          repeat: Number.POSITIVE_INFINITY,
          repeatDelay: 20,
          delay: 5,
        }}
      >
        <div>{"SELECT * FROM users WHERE username='' OR 1=1--'"}</div>
      </motion.div>

      <motion.div
        className="fixed top-1/2 left-20 bg-black/50 border border-yellow-500/30 rounded p-2 font-mono text-xs text-yellow-500 max-w-xs"
        initial={{ opacity: 0 }}
        animate={{
          opacity: [0, 0.7, 0],
          y: [0, 20, 0],
        }}
        transition={{
          duration: 8,
          repeat: Number.POSITIVE_INFINITY,
          repeatDelay: 25,
          delay: 10,
        }}
      >
        <div>{"curl -X POST https://api.target.com/reset?email=admin@target.com"}</div>
      </motion.div>
    </div>
  )
}

