"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Github, Linkedin, Instagram, Twitter } from "lucide-react"
import type { JSX } from "react"

interface SocialLink {
  name: string
  icon: JSX.Element
  url: string
  color: string
}

export function SocialLinks() {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null)

  const socialLinks: SocialLink[] = [
    {
      name: "LinkedIn",
      icon: <Linkedin className="w-5 h-5" />,
      url: "https://www.linkedin.com/in/olial-kibria-konok-75001827b",
      color: "#0A66C2",
    },
    {
      name: "Twitter",
      icon: <Twitter className="w-5 h-5" />,
      url: "https://x.com/nine_am_",
      color: "#1DA1F2",
    },
    {
      name: "Instagram",
      icon: <Instagram className="w-5 h-5" />,
      url: "https://www.instagram.com/olialkibriakonok",
      color: "#E4405F",
    },
    {
      name: "GitHub",
      icon: <Github className="w-5 h-5" />,
      url: "https://github.com/9amx",
      color: "#6e5494",
    },
  ]

  return (
    <div className="flex justify-center gap-4">
      {socialLinks.map((link, index) => (
        <motion.a
          key={link.name}
          href={link.url}
          target="_blank"
          rel="noopener noreferrer"
          className="relative group"
          onMouseEnter={() => setHoveredIndex(index)}
          onMouseLeave={() => setHoveredIndex(null)}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
        >
          <div
            className="flex items-center justify-center w-12 h-12 rounded-lg bg-gray-900 border border-gray-800 transition-all duration-300 overflow-hidden"
            style={{
              borderColor: hoveredIndex === index ? link.color : "rgba(31, 41, 55, 0.5)",
              boxShadow: hoveredIndex === index ? `0 0 15px ${link.color}40` : "none",
            }}
          >
            <div
              className="text-gray-400 transition-colors duration-300"
              style={{
                color: hoveredIndex === index ? link.color : "rgba(156, 163, 175, 1)",
              }}
            >
              {link.icon}
            </div>

            {/* Animated highlight effect */}
            <motion.div
              className="absolute inset-0 opacity-0 bg-gradient-to-br"
              style={{
                backgroundImage: `linear-gradient(135deg, ${link.color}20, transparent)`,
                opacity: hoveredIndex === index ? 0.5 : 0,
              }}
              animate={{
                opacity: hoveredIndex === index ? 0.5 : 0,
              }}
              transition={{ duration: 0.3 }}
            />
          </div>

          {/* Name tooltip */}
          <motion.div
            className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 bg-gray-900 px-2 py-1 rounded text-xs font-mono pointer-events-none"
            initial={{ opacity: 0, y: -5 }}
            animate={{
              opacity: hoveredIndex === index ? 1 : 0,
              y: hoveredIndex === index ? 0 : -5,
            }}
            transition={{ duration: 0.2 }}
          >
            {link.name}
          </motion.div>
        </motion.a>
      ))}
    </div>
  )
}

