"use client"

import { useEffect, useState, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Terminal } from "lucide-react"
import { TypewriterEffect } from "@/components/ui/typewriter-effect"
import { GlitchText } from "@/components/ui/glitch-text"
import { HolographicBackground } from "@/components/ui/holographic-background"
import { CyberCard } from "@/components/ui/cyber-card"
import { DigitalClock } from "@/components/ui/digital-clock"
import { FloatingIcons } from "@/components/ui/floating-icons"
import { LoadingAnimation } from "@/components/ui/loading-animation"
import { SocialLinks } from "@/components/ui/social-links"
import { CertificateCard } from "@/components/ui/certificate-card"
import { PlatformBadges } from "@/components/ui/platform-badges"
import { CustomCursor } from "@/components/ui/custom-cursor"
import { BugBountyPlatforms } from "@/components/ui/bug-bounty-platforms"
import { AnimatedTerminal } from "@/components/ui/animated-terminal"
import { CodeParticles } from "@/components/ui/code-particles"
import { BugHuntingEffects } from "@/components/ui/bug-hunting-effects"
import { DynamicCodeDisplay } from "@/components/ui/dynamic-code-display"
import { ProfileImage } from "@/components/ui/profile-image"

// Fix: Export the component as the default export
export default function Page() {
  const [loading, setLoading] = useState(true)
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const [audioInitialized, setAudioInitialized] = useState(false)
  const [audioPreloaded, setAudioPreloaded] = useState(false)

  // Preload audio before initializing
  useEffect(() => {
    // Create an audio element for preloading
    const preloadAudio = new Audio()

    // Set up event listeners for preloading
    preloadAudio.addEventListener("canplaythrough", () => {
      console.log("Audio preloaded successfully")
      setAudioPreloaded(true)
    })

    preloadAudio.addEventListener("error", (e) => {
      console.error("Audio preload error:", e)
      // Still set as preloaded to not block the experience
      setAudioPreloaded(true)
    })

    // Start preloading
    preloadAudio.src =
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/videoplayback%20%28mp3cut.net%29-YyXerxv1mmNRxzu6eaxQDLuKtIJ8KM.mp3"
    preloadAudio.load()

    return () => {
      preloadAudio.src = ""
    }
  }, [])

  // Initialize audio after preloading
  useEffect(() => {
    if (!audioPreloaded) return

    const audio = new Audio(
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/videoplayback%20%28mp3cut.net%29-YyXerxv1mmNRxzu6eaxQDLuKtIJ8KM.mp3",
    )
    audio.loop = true // Ensure loop is set to true
    audio.volume = 0.3
    audio.setAttribute("data-main-audio", "true")

    // Add event listener to ensure looping works across all browsers
    audio.addEventListener(
      "ended",
      function () {
        this.currentTime = 0
        this.play().catch((e) => console.log("Auto-replay prevented:", e))
      },
      false,
    )

    // Reduce audio processing load
    if (audio.mozPreservesPitch !== undefined) {
      // Firefox
      audio.mozPreservesPitch = false
    } else if ((audio as any).preservesPitch !== undefined) {
      // Chrome
      ;(audio as any).preservesPitch = false
    }

    audioRef.current = audio
    setAudioInitialized(true)

    return () => {
      if (audioRef.current) {
        audioRef.current.pause()
        audioRef.current.src = ""
      }
    }
  }, [audioPreloaded])

  // Handle loading completion
  useEffect(() => {
    if (loading) {
      const timer = setTimeout(() => {
        setLoading(false)

        // Try to play audio after a short delay
        setTimeout(() => {
          if (audioRef.current && audioInitialized) {
            audioRef.current.play().catch((err) => {
              console.log("Autoplay prevented by browser. User will need to click play button.")
            })
          }
        }, 500)
      }, 3500)

      return () => clearTimeout(timer)
    }
  }, [loading, audioInitialized])

  // Set up event listeners for user interaction to play audio
  useEffect(() => {
    const handleUserInteraction = () => {
      if (audioRef.current && audioInitialized && audioRef.current.paused) {
        // Use a short timeout to reduce competition with other resources
        setTimeout(() => {
          audioRef.current?.play().catch((err) => {
            console.log("Still couldn't play audio:", err)
          })
        }, 100)
      }
    }

    // Add listeners for common user interactions
    window.addEventListener("click", handleUserInteraction, { once: true })
    window.addEventListener("touchstart", handleUserInteraction, { once: true })
    window.addEventListener("keydown", handleUserInteraction, { once: true })

    return () => {
      window.removeEventListener("click", handleUserInteraction)
      window.removeEventListener("touchstart", handleUserInteraction)
      window.removeEventListener("keydown", handleUserInteraction)
    }
  }, [audioInitialized])

  // Reduce animation complexity when audio is playing to prevent lag
  const [reduceAnimations, setReduceAnimations] = useState(false)

  useEffect(() => {
    if (!audioRef.current) return

    const handlePlay = () => setReduceAnimations(true)
    const handlePause = () => setReduceAnimations(false)

    audioRef.current.addEventListener("play", handlePlay)
    audioRef.current.addEventListener("pause", handlePause)

    return () => {
      if (audioRef.current) {
        audioRef.current.removeEventListener("play", handlePlay)
        audioRef.current.removeEventListener("pause", handlePause)
      }
    }
  }, [audioInitialized])

  return (
    <div className="min-h-screen bg-black text-white overflow-hidden">
      {/* Use the optimized custom cursor component */}
      <CustomCursor />

      {/* Audio functionality remains active but without visible controls */}

      <AnimatePresence mode="wait">
        {loading ? (
          <motion.div
            key="loader"
            className="fixed inset-0 z-50 flex items-center justify-center bg-black"
            exit={{
              opacity: 0,
              transition: { duration: 0.5 },
            }}
          >
            <LoadingAnimation />
          </motion.div>
        ) : (
          <motion.div
            key="content"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="relative w-full min-h-screen"
          >
            {/* Background effects - conditionally reduce complexity */}
            <HolographicBackground reduced={reduceAnimations} />
            {/* Background effects */}
            {!reduceAnimations && <CodeParticles />}
            {!reduceAnimations && <BugHuntingEffects />}

            <Header />
            <Hero />
            <Certificates />
            <BugBountyPlatforms />
            <AnimatedTerminal />
            <Footer />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

// Rest of the component functions remain the same
function Header() {
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled ? "bg-black/80 backdrop-blur-md border-b border-gray-800/50" : "bg-transparent"
      }`}
    >
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="flex items-center"
        >
          <div className="relative">
            <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-emerald-500 to-cyan-500">
              9am
            </div>
            <div className="absolute -bottom-1 left-0 w-full h-px bg-gradient-to-r from-emerald-500 to-cyan-500"></div>
          </div>
          <DigitalClock className="ml-6 text-sm text-gray-500" />
        </motion.div>
      </div>
    </header>
  )
}

function Hero() {
  return (
    <section className="pt-32 pb-20 relative min-h-screen flex items-center">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(16,185,129,0.08),transparent_70%)]" />

      {/* Keep FloatingIcons as they've been reduced in number */}
      <FloatingIcons />

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-center mb-16"
          >
            {/* Add profile image */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="mb-8 flex justify-center"
            >
              <ProfileImage className="w-40 h-40 md:w-48 md:h-48" />
            </motion.div>

            <div className="inline-block mb-6 px-4 py-1 border border-emerald-500/30 rounded-full bg-emerald-500/10 text-emerald-500 text-sm font-mono">
              <span>Cybersecurity Specialist & Bug Hunter</span>
            </div>

            <h1 className="text-3xl md:text-6xl font-bold mb-16 leading-tight">
              <div className="mb-6 pt-8">
                <DynamicCodeDisplay name="Olial Kibria Konok" alias="9am" />
              </div>
            </h1>

            <p className="text-xl text-gray-400 mb-8 font-mono">
              <span className="text-emerald-500">{">"}</span> Finding vulnerabilities others miss
            </p>

            <SocialLinks />
            <PlatformBadges />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.8 }}
          >
            <CyberCard>
              <div className="p-8">
                <div className="flex items-center mb-4">
                  <Terminal className="w-5 h-5 text-emerald-500 mr-2" />
                  <h2 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-emerald-500 to-cyan-500">
                    About Me
                  </h2>
                </div>

                <div className="font-mono text-gray-300 space-y-4">
                  <p>
                    <span className="text-emerald-500">{">"}</span> I am a passionate cybersecurity specialist and bug
                    hunter with expertise in identifying and resolving security vulnerabilities across various
                    platforms.
                  </p>
                  <p>
                    <span className="text-emerald-500">{">"}</span> With a keen eye for detail and a deep understanding
                    of hacker methodologies, I help organizations strengthen their security posture.
                  </p>
                  <p>
                    <span className="text-emerald-500">{">"}</span> My approach combines technical expertise with
                    creative problem-solving to uncover security issues that automated tools might miss.
                  </p>
                  <p>
                    <span className="text-emerald-500">{">"}</span> Active security researcher at{" "}
                    <span className="text-red-400 font-semibold">HackerOne</span>,{" "}
                    <span className="text-yellow-400 font-semibold">Yes We Hack</span>,{" "}
                    <span className="text-orange-400 font-semibold">Bugcrowd</span>, and{" "}
                    <span className="text-blue-400 font-semibold">Intigriti</span> bug bounty platforms.
                  </p>
                </div>
              </div>
            </CyberCard>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

function Certificates() {
  const certificates = [
    {
      title: "CEH v12 - Certified Ethical Hacker",
      issuer: "EC-Council / Udemy",
      date: "March 6, 2024",
      description:
        "Comprehensive training in ethical hacking methodologies, tools, and techniques used by security professionals and malicious hackers.",
      imageUrl:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/UC-15dcda49-6db2-4db1-8807-a08f3adbb53b_3.jpg-rU3t5TkabkU9Zd9WZXSr2npUVWuWBt.jpeg",
      duration: "40 total hours",
    },
    {
      title: "CompTIA Security+ (SY0-601)",
      issuer: "Cybrary",
      date: "March 25, 2024",
      description:
        "Foundational cybersecurity certification covering essential security concepts, tools, and procedures.",
      imageUrl:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/5_6057450268860092014_240325_172755.jpg-ueLjoaPsHGNfSQMyXIbVFAyeVhQymq.jpeg",
      duration: "10 hours",
    },
    {
      title: "Penetration Testing and Ethical Hacking",
      issuer: "Cybrary",
      date: "March 25, 2024",
      description: "Advanced training in penetration testing methodologies and ethical hacking techniques.",
      imageUrl:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/5_6057450268860092017_240325_174316.jpg-RxCpSTtERAdEd2rKjP3BN386DFTNSd.jpeg",
      duration: "7 hours",
    },
    {
      title: "Digital Forensics and Electronic Evidence",
      issuer: "Udemy",
      date: "June 2, 2024",
      description:
        "Specialized training in digital forensics techniques and electronic evidence handling for cybersecurity investigations.",
      imageUrl:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/UC-c0554d35-b280-4ef9-80b7-85c753aa6e03.jpg-Xa5f72OLaylLIwMEIsb74A0mv3JpRp.jpeg",
      duration: "1 hour",
    },
    {
      title: "Bug Bounty & Website Penetration Testing",
      issuer: "Udemy",
      date: "July 13, 2024",
      description:
        "Practical training in identifying and exploiting web application vulnerabilities for bug bounty programs.",
      imageUrl:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/UC-d3273a4f-6b98-4c83-8c35-ddbd7e4d3b9a.jpg-WTLc2fauF0lAOaelO2TA4SlOaOPg0I.jpeg",
      duration: "1.5 hours",
    },
    {
      title: "Penetration Testing for eJPT Certification",
      issuer: "Udemy",
      date: "Nov 30, 2024",
      description: "Preparation course for the eLearnSecurity Junior Penetration Tester (eJPT) certification exam.",
      imageUrl:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/UC-508a0500-26cb-41f4-b643-861371fcc97d.jpg-Em6UoSNV3rHZAXoSRB9SyFSV6KggBR.jpeg",
      duration: "5.5 hours",
    },
    {
      title: "Ethical Hacking Essentials (EHE)",
      issuer: "EC-Council",
      date: "March 13, 2024",
      description: "Foundational course in ethical hacking principles, methodologies, and best practices.",
      imageUrl:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/eb6ddfe6-9c48-4343-ad83-bb6b5594e99a-uGZ5U1KdMmh0oim2nZYW9pznKlVlZq.png",
      duration: "10 hours",
    },
  ]

  return (
    <section className="py-20 relative" id="certificates">
      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-block mb-4 px-4 py-1 border border-emerald-500/30 rounded-full bg-emerald-500/10 text-emerald-500 text-sm font-mono">
            CREDENTIALS
          </div>
          <GlitchText text="Certificates & Achievements" className="text-4xl font-bold mb-4" />
          <p className="text-gray-400 max-w-2xl mx-auto font-mono">
            <TypewriterEffect
              text="Professional certifications and recognition in the field of cybersecurity"
              speed={30}
            />
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {certificates.map((cert, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <CertificateCard
                title={cert.title}
                issuer={cert.issuer}
                date={cert.date}
                description={cert.description}
                imageUrl={cert.imageUrl}
                duration={cert.duration}
              />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

function Footer() {
  return (
    <footer className="py-12 bg-black border-t border-gray-900/50 relative">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-6 md:mb-0">
              <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-emerald-500 to-cyan-500 mb-2">
                9am
              </div>
              <p className="text-gray-500 text-sm font-mono">Cybersecurity Specialist & Bug Hunter</p>
            </div>

            <SocialLinks />
          </div>

          <div className="border-t border-gray-900/50 mt-8 pt-8 text-center">
            <p className="text-gray-500 text-sm font-mono">
              © {new Date().getFullYear()} Olial Kibria Konok (9am). All rights reserved.
            </p>
            <p className="text-gray-700 text-xs mt-2 font-mono">
              <span className="text-emerald-700">{">"}</span> Securing the digital world, one vulnerability at a time.
            </p>
          </div>
        </div>
      </div>
    </footer>
  )
}

